@echo off
setlocal DisableDelayedExpansion
set "ZT_PS1=%~dp0ZeroTrust_Firewall_Monitor.ps1"
if not exist "%ZT_PS1%" (
  echo PowerShell engine not found: "%ZT_PS1%"
  exit /b 2
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$scriptPath=$env:ZT_PS1; $ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'; $argLine='-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $scriptPath + '"'; $id=[Security.Principal.WindowsIdentity]::GetCurrent(); $principal=New-Object Security.Principal.WindowsPrincipal($id); if($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){ Start-Process -FilePath $ps -ArgumentList $argLine -ErrorAction Stop | Out-Null } else { Start-Process -FilePath $ps -ArgumentList $argLine -Verb RunAs -ErrorAction Stop | Out-Null }"
if errorlevel 1 exit /b 3
exit /b 0
