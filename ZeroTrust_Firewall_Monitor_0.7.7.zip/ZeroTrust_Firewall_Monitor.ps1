﻿#requires -Version 5.1
# Build 0.7.7 - Wireshark.exe only; removed command-line analyzer dependency and automatic CLI audit.
$ErrorActionPreference = 'Stop'
$ManagedRuleGroup = 'ZeroTrust - Managed'
$LegacyRuleGroup = 'Zero-Trust Whitelist'
$StateDirectory = Join-Path $env:ProgramData 'ZeroTrustFirewallMonitor'
$StatePath = Join-Path $StateDirectory 'FirewallState.json'
$FullPolicyBackupPath = Join-Path $StateDirectory 'rulle.wfw'
$AuditStatePath = Join-Path $StateDirectory 'FilteringPlatformAuditState.json'
$DecisionPath = Join-Path $StateDirectory 'RememberedDecisions.json'
$CaptureDirectory = Join-Path $StateDirectory 'Captures'
$OwnerPath = Join-Path $CaptureDirectory 'PktmonOwner.json'
$Pktmon = Join-Path $env:SystemRoot 'System32\pktmon.exe'
$MutexName = 'Global\ZeroTrustPktmonCaptureLock'
$LogPath = Join-Path $StateDirectory 'ZeroTrust_Monitor.log'
$AuditSubcategoryGuid = '{0CCE9226-69AE-11D9-BED3-505054503030}'
$ProfilesToManage = @('Domain','Private','Public')
# Managed-rule cache is read-only and refreshed at monitor start and after new rules.
$script:ManagedRuleCache = @()
$script:ManagedRuleCacheReady = $false
$script:ApplicationTrustCache = @{}
# In-memory only: [I] suppresses the same connection for this monitor session.
$script:SessionIgnoredConnectionKeys = @{}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 -ErrorAction Stop }
    catch { Write-Warning ('Could not write log: ' + $_.Exception.Message) }
}

function Ensure-StateDirectory {
    if (-not (Test-Path -LiteralPath $StateDirectory)) {
        New-Item -Path $StateDirectory -ItemType Directory -Force -ErrorAction Stop | Out-Null
    }
    # State and logs are accessible only to SYSTEM and local Administrators.
    & icacls.exe $StateDirectory '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' *> $null
    if ($LASTEXITCODE -ne 0) {
        throw 'Could not restrict permissions on the state directory. No firewall changes were made.'
    }
}

function Get-Sha256Hex {
    param([Parameter(Mandatory=$true)][string]$Text)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','')
    }
    finally { $sha.Dispose() }
}

function Get-FirewallSnapshot {
    $profiles = @(Get-NetFirewallProfile -Profile $ProfilesToManage -PolicyStore PersistentStore -ErrorAction Stop)
    if ($profiles.Count -ne 3) { throw 'Windows did not return all three firewall profiles.' }

    $items = @()
    foreach ($profileName in $ProfilesToManage) {
        $profile = $profiles | Where-Object { $_.Name -eq $profileName } | Select-Object -First 1
        if (-not $profile) { throw ('Missing firewall profile: ' + $profileName) }
        $items += [ordered]@{
            Name = [string]$profile.Name
            Enabled = [string]$profile.Enabled
            DefaultInboundAction = [string]$profile.DefaultInboundAction
            DefaultOutboundAction = [string]$profile.DefaultOutboundAction
            AllowLocalFirewallRules = [string]$profile.AllowLocalFirewallRules
        }
    }
    return $items
}

function Get-FirewallRuleInventorySnapshot {
    # Fingerprint every persistent local firewall rule. This is intentionally
    # metadata-only and does not alter rule objects or their filters.
    $rules = @(Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop)
    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($rule in $rules) {
        $record = @(
            [string]$rule.Name,
            [string]$rule.DisplayName,
            [string]$rule.Group,
            [string]$rule.Description,
            [string]$rule.Enabled,
            [string]$rule.Direction,
            [string]$rule.Action,
            [string]$rule.Profile
        )
        $lines.Add((ConvertTo-Json -InputObject $record -Compress))
    }
    $canonical = [string]::Join("`n", [string[]]@($lines.ToArray() | Sort-Object -CaseSensitive))
    return [ordered]@{
        Count = [int]$rules.Count
        Sha256 = (Get-Sha256Hex -Text $canonical)
    }
}

function Export-FullFirewallPolicyBackup {
    param([Parameter(Mandatory=$true)][string]$DestinationPath)
    $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    if (-not (Test-Path -LiteralPath $netsh -PathType Leaf)) { throw 'netsh.exe was not found; complete firewall backup is unavailable.' }
    if (Test-Path -LiteralPath $DestinationPath) { throw ('Refusing to overwrite an existing full firewall backup: ' + $DestinationPath) }

    $directory = Split-Path -Parent $DestinationPath
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
        New-Item -Path $directory -ItemType Directory -Force -ErrorAction Stop | Out-Null
    }
    $tempPath = Join-Path $directory ('FirewallPolicy.' + $PID + '.' + [Guid]::NewGuid().ToString('N') + '.tmp.wfw')
    try {
        $nativeOutput = @(& $netsh advfirewall export $tempPath 2>&1)
        $exitCode = $LASTEXITCODE
        if ($exitCode -ne 0 -or -not (Test-Path -LiteralPath $tempPath -PathType Leaf)) {
            $detail = [string]::Join(' ', [string[]]$nativeOutput)
            throw ('netsh advfirewall export failed (exit ' + $exitCode + '). ' + $detail)
        }
        $file = Get-Item -LiteralPath $tempPath -ErrorAction Stop
        if ($file.Length -lt 128) { throw 'The exported firewall policy file is unexpectedly small; backup rejected.' }

        $inventory = Get-FirewallRuleInventorySnapshot
        Move-Item -LiteralPath $tempPath -Destination $DestinationPath -ErrorAction Stop
        $savedFile = Get-Item -LiteralPath $DestinationPath -ErrorAction Stop
        $fileHash = (Get-FileHash -LiteralPath $DestinationPath -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
        return [ordered]@{
            FileName = [System.IO.Path]::GetFileName($DestinationPath)
            Sha256 = $fileHash
            Length = [long]$savedFile.Length
            ExportedUtc = [DateTime]::UtcNow.ToString('o')
            PersistentRuleCount = [int]$inventory.Count
            PersistentRulesSha256 = [string]$inventory.Sha256
        }
    }
    finally {
        if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
    }
}

function Write-FirewallSnapshotFile {
    param([Parameter(Mandatory=$true)]$Snapshot)
    $payloadJson = ConvertTo-Json -InputObject $Snapshot -Depth 8 -Compress
    $envelope = [ordered]@{
        PayloadJson = $payloadJson
        Sha256 = Get-Sha256Hex -Text $payloadJson
    }
    $json = ConvertTo-Json -InputObject $envelope -Depth 4
    $tempPath = $StatePath + '.' + $PID + '.tmp'
    try {
        [System.IO.File]::WriteAllText($tempPath, $json, (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tempPath -Destination $StatePath -Force -ErrorAction Stop
    }
    finally {
        if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
    }
}

function Save-FirewallSnapshot {
    Ensure-StateDirectory
    if (Test-Path -LiteralPath $StatePath -PathType Leaf) {
        throw 'A firewall baseline already exists. It will not be overwritten.'
    }

    # Export the complete policy before applying strict profile settings.
    $fullPolicy = Export-FullFirewallPolicyBackup -DestinationPath $FullPolicyBackupPath
    try {
        $snapshot = [ordered]@{
            SchemaVersion = 2
            ComputerName = $env:COMPUTERNAME
            CreatedUtc = [DateTime]::UtcNow.ToString('o')
            Profiles = @(Get-FirewallSnapshot)
            FullPolicyBackup = $fullPolicy
        }
        Write-FirewallSnapshotFile -Snapshot $snapshot
    }
    catch {
        # Do not leave an unreferenced partial baseline that could be mistaken
        # for the active backup on the next run.
        if (Test-Path -LiteralPath $FullPolicyBackupPath) {
            Remove-Item -LiteralPath $FullPolicyBackupPath -Force -ErrorAction SilentlyContinue
        }
        throw
    }
    Write-Log ('Saved complete Windows Firewall policy backup: ' + $FullPolicyBackupPath)
}

function Read-FirewallSnapshot {
    if (-not (Test-Path -LiteralPath $StatePath -PathType Leaf)) {
        throw 'No saved firewall state exists. Nothing can be restored.'
    }
    $envelope = Get-Content -LiteralPath $StatePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace([string]$envelope.PayloadJson) -or [string]::IsNullOrWhiteSpace([string]$envelope.Sha256)) {
        throw 'Firewall state file is incomplete. It has not been used.'
    }
    $actualHash = Get-Sha256Hex -Text ([string]$envelope.PayloadJson)
    if ($actualHash -ne [string]$envelope.Sha256) {
        throw 'Firewall state SHA-256 integrity check failed. The file has not been used.'
    }
    $snapshot = [string]$envelope.PayloadJson | ConvertFrom-Json -ErrorAction Stop
    if ([int]$snapshot.SchemaVersion -notin @(1,2)) { throw 'Unsupported firewall state schema.' }
    if ([string]$snapshot.ComputerName -ne [string]$env:COMPUTERNAME) {
        throw 'The saved state belongs to a different computer. Restore was refused.'
    }
    if (@($snapshot.Profiles).Count -ne 3) { throw 'The saved state does not contain all three firewall profiles.' }
    foreach ($name in $ProfilesToManage) {
        $profile = @($snapshot.Profiles | Where-Object { $_.Name -eq $name })
        if ($profile.Count -ne 1) { throw ('Invalid saved profile entry: ' + $name) }
        if ($profile[0].Enabled -notin @('True','False') -or
            $profile[0].AllowLocalFirewallRules -notin @('True','False') -or
            $profile[0].DefaultInboundAction -notin @('Allow','Block') -or
            $profile[0].DefaultOutboundAction -notin @('Allow','Block')) {
            throw ('Invalid saved values for profile: ' + $name)
        }
    }
    if ([int]$snapshot.SchemaVersion -ge 2) {
        $full = $snapshot.FullPolicyBackup
        if (-not $full -or [string]$full.FileName -notin @('rulle.wfw','FirewallPolicy.wfw') -or
            [string]$full.Sha256 -notmatch '^[A-Fa-f0-9]{64}$' -or
            [long]$full.Length -lt 128 -or
            [int]$full.PersistentRuleCount -lt 0 -or
            [string]$full.PersistentRulesSha256 -notmatch '^[A-Fa-f0-9]{64}$') {
            throw 'The full firewall policy backup metadata is invalid. Restore was refused.'
        }
        $verifiedPolicyPath = Join-Path $StateDirectory ([string]$full.FileName)
        if (-not (Test-Path -LiteralPath $verifiedPolicyPath -PathType Leaf)) {
            throw 'The complete firewall policy backup file is missing. Strict mode will not proceed.'
        }
        $verifiedPolicyFile = Get-Item -LiteralPath $verifiedPolicyPath -ErrorAction Stop
        if ([long]$verifiedPolicyFile.Length -ne [long]$full.Length) {
            throw 'The complete firewall policy backup length check failed. It has not been used.'
        }
        $verifiedPolicyHash = (Get-FileHash -LiteralPath $verifiedPolicyPath -Algorithm SHA256 -ErrorAction Stop).Hash
        if ($verifiedPolicyHash -ne [string]$full.Sha256) {
            throw 'The complete firewall policy backup SHA-256 check failed. It has not been used.'
        }
    }
    return $snapshot
}

function Upgrade-LegacyFirewallSnapshotToFull {
    # Older builds saved only three profile settings. They cannot contain a
    # historical rules baseline, so capture all current persistent rules once
    # during upgrade while preserving the original saved profile values.
    $snapshot = Read-FirewallSnapshot
    if ([int]$snapshot.SchemaVersion -ge 2) { return $snapshot }
    $fullPolicy = Export-FullFirewallPolicyBackup -DestinationPath $FullPolicyBackupPath
    $upgraded = [ordered]@{
        SchemaVersion = 2
        ComputerName = [string]$snapshot.ComputerName
        CreatedUtc = [string]$snapshot.CreatedUtc
        Profiles = @($snapshot.Profiles)
        FullPolicyBackup = $fullPolicy
    }
    try { Write-FirewallSnapshotFile -Snapshot $upgraded }
    catch {
        if (Test-Path -LiteralPath $FullPolicyBackupPath) {
            Remove-Item -LiteralPath $FullPolicyBackupPath -Force -ErrorAction SilentlyContinue
        }
        throw
    }
    Write-Log ('Upgraded legacy profile-only backup. Full rule baseline captured at upgrade time: ' + $FullPolicyBackupPath) 'WARNING'
    Write-Host '[BACKUP UPGRADED] All current persistent firewall rules are now backed up.' -ForegroundColor Green
    Write-Host '[LEGACY LIMITATION] The previous version saved profiles only; historical rule changes from before this upgrade cannot be reconstructed.' -ForegroundColor Yellow
    return (Read-FirewallSnapshot)
}

function Restore-FirewallSnapshot {
    param([switch]$KeepBackup)
    $snapshot = Read-FirewallSnapshot
    if ([int]$snapshot.SchemaVersion -lt 2 -or -not $snapshot.FullPolicyBackup) {
        throw 'This is a legacy profile-only backup. It cannot restore the complete firewall rule set. No firewall settings were changed.'
    }

    # Read-FirewallSnapshot has already restricted FileName to the known
    # backup names and verified its hash; allow 0.7.5's legacy filename here
    # so automatic rollback still works during a failed strict-mode startup.
    $fullPath = Join-Path $StateDirectory ([string]$snapshot.FullPolicyBackup.FileName)
    $resolvedFullPath = [System.IO.Path]::GetFullPath($fullPath)
    $resolvedStateDirectory = [System.IO.Path]::GetFullPath($StateDirectory + [System.IO.Path]::DirectorySeparatorChar)
    if (-not $resolvedFullPath.StartsWith($resolvedStateDirectory,[StringComparison]::OrdinalIgnoreCase) -or
        -not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        throw 'The full firewall policy backup file is missing or has an unexpected path. Restore was refused.'
    }
    $backupFile = Get-Item -LiteralPath $fullPath -ErrorAction Stop
    if ([long]$backupFile.Length -ne [long]$snapshot.FullPolicyBackup.Length) {
        throw 'Full firewall policy backup length check failed. Restore was refused.'
    }
    $actualPolicyHash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256 -ErrorAction Stop).Hash
    if ($actualPolicyHash -ne [string]$snapshot.FullPolicyBackup.Sha256) {
        throw 'Full firewall policy SHA-256 integrity check failed. Restore was refused.'
    }

    $auditSnapshot = $null
    if (Test-Path -LiteralPath $AuditStatePath -PathType Leaf) {
        # Validate the separate audit-policy backup before changing firewall settings.
        $auditSnapshot = Read-FilteringPlatformAuditSnapshot
    }
    $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    if (-not (Test-Path -LiteralPath $netsh -PathType Leaf)) { throw 'netsh.exe was not found. Complete restore is unavailable.' }

    # Keep a one-operation rollback image of the current policy in case import
    # or post-import verification fails. This file is not the saved baseline.
    $preRestorePath = Join-Path $StateDirectory ('FirewallPolicy.pre-restore-' + [Guid]::NewGuid().ToString('N') + '.wfw')
    $preRestoreCreated = $false
    $restoreVerified = $false
    Write-Host "`nRestoring the complete saved Windows Firewall policy (all local persistent rules) ..." -ForegroundColor Cyan
    try {
        $null = Export-FullFirewallPolicyBackup -DestinationPath $preRestorePath
        $preRestoreCreated = $true

        $nativeOutput = @(& $netsh advfirewall import $fullPath 2>&1)
        $importExitCode = $LASTEXITCODE
        if ($importExitCode -ne 0) {
            $detail = [string]::Join(' ', [string[]]$nativeOutput)
            throw ('netsh advfirewall import failed (exit ' + $importExitCode + '). ' + $detail)
        }

        # The .wfw file restores the complete policy; explicitly apply and
        # verify the saved three profile settings as a second check.
        foreach ($saved in $snapshot.Profiles) {
            Set-NetFirewallProfile -Profile ([string]$saved.Name) `
                -Enabled ([string]$saved.Enabled -eq 'True') `
                -DefaultInboundAction ([string]$saved.DefaultInboundAction) `
                -DefaultOutboundAction ([string]$saved.DefaultOutboundAction) `
                -AllowLocalFirewallRules ([string]$saved.AllowLocalFirewallRules -eq 'True') -ErrorAction Stop
        }

        $currentProfiles = @(Get-NetFirewallProfile -Profile $ProfilesToManage -PolicyStore PersistentStore -ErrorAction Stop)
        foreach ($saved in $snapshot.Profiles) {
            $actual = $currentProfiles | Where-Object { $_.Name -eq $saved.Name } | Select-Object -First 1
            if (-not $actual -or
                [string]$actual.Enabled -ne [string]$saved.Enabled -or
                [string]$actual.DefaultInboundAction -ne [string]$saved.DefaultInboundAction -or
                [string]$actual.DefaultOutboundAction -ne [string]$saved.DefaultOutboundAction -or
                [string]$actual.AllowLocalFirewallRules -ne [string]$saved.AllowLocalFirewallRules) {
                throw ('Restored profile verification failed for ' + $saved.Name + '.')
            }
        }

        $restoredInventory = Get-FirewallRuleInventorySnapshot
        if ([int]$restoredInventory.Count -ne [int]$snapshot.FullPolicyBackup.PersistentRuleCount -or
            [string]$restoredInventory.Sha256 -ne [string]$snapshot.FullPolicyBackup.PersistentRulesSha256) {
            throw ('Restored local firewall rule inventory does not match the saved baseline. Expected ' +
                $snapshot.FullPolicyBackup.PersistentRuleCount + ' rules; found ' + $restoredInventory.Count + '.')
        }
        $restoreVerified = $true
    }
    catch {
        $restoreError = $_.Exception.Message
        if ($preRestoreCreated -and (Test-Path -LiteralPath $preRestorePath -PathType Leaf)) {
            Write-Host '[RESTORE RECOVERY] Restoring the firewall policy that was active before this attempt...' -ForegroundColor Yellow
            try {
                $rollbackOutput = @(& $netsh advfirewall import $preRestorePath 2>&1)
                $rollbackExit = $LASTEXITCODE
                if ($rollbackExit -eq 0) {
                    Write-Host '[RESTORE RECOVERY VERIFIED BY NETSH] The pre-restore policy was re-imported.' -ForegroundColor Green
                    Remove-Item -LiteralPath $preRestorePath -Force -ErrorAction SilentlyContinue
                }
                else {
                    Write-Host ('[RECOVERY WARNING] Automatic rollback failed (exit ' + $rollbackExit + '). Recovery file retained: ' + $preRestorePath) -ForegroundColor Red
                    $preRestoreCreated = $false
                }
            }
            catch {
                Write-Host ('[RECOVERY WARNING] Automatic rollback failed: ' + $_.Exception.Message + '. Recovery file retained: ' + $preRestorePath) -ForegroundColor Red
                $preRestoreCreated = $false
            }
        }
        throw ('Complete firewall restore did not pass verification. Saved backup retained. ' + $restoreError)
    }
    finally {
        if ($restoreVerified -and $preRestoreCreated -and (Test-Path -LiteralPath $preRestorePath)) {
            Remove-Item -LiteralPath $preRestorePath -Force -ErrorAction SilentlyContinue
        }
    }

    if ($null -ne $auditSnapshot) {
        Restore-FilteringPlatformAuditSnapshot -Snapshot $auditSnapshot -KeepBackup:$KeepBackup
    }
    Write-Log 'Complete saved firewall policy restored and verified, including the local persistent rule inventory.' 'INFO'
    Write-Host '[RESTORE VERIFIED] Saved profiles and all saved local persistent firewall rules are restored.' -ForegroundColor Green
    Write-Host 'Note: Active Directory / domain Group Policy is controlled by its policy source and may reapply separately.' -ForegroundColor Yellow

    if (-not $KeepBackup) {
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        $archiveState = Join-Path $StateDirectory ('FirewallState.restored-' + $stamp + '.json')
        $archivePolicy = Join-Path $StateDirectory ('FirewallPolicy.restored-' + $stamp + '.wfw')
        Move-Item -LiteralPath $StatePath -Destination $archiveState -ErrorAction Stop
        if (Test-Path -LiteralPath $FullPolicyBackupPath -PathType Leaf) {
            Move-Item -LiteralPath $FullPolicyBackupPath -Destination $archivePolicy -ErrorAction Stop
        }
        Write-Host ('Full backup archived: ' + $archiveState + ' and ' + $archivePolicy) -ForegroundColor Gray
    }
}


function Save-RulleFirewallPolicy {
    Ensure-StateDirectory
    $stagePath = Join-Path $StateDirectory ('rulle.stage.' + $PID + '.' + [Guid]::NewGuid().ToString('N') + '.wfw')
    $previousPath = Join-Path $StateDirectory ('rulle.previous.' + $PID + '.' + [Guid]::NewGuid().ToString('N') + '.wfw')
    $hadPrevious = Test-Path -LiteralPath $FullPolicyBackupPath -PathType Leaf
    $committed = $false

    try {
        if ($hadPrevious) {
            Copy-Item -LiteralPath $FullPolicyBackupPath -Destination $previousPath -ErrorAction Stop
        }

        $metadata = Export-FullFirewallPolicyBackup -DestinationPath $stagePath
        $metadata.FileName = 'rulle.wfw'

        # The selected [1] action is the user's instruction to refresh this backup.
        Move-Item -LiteralPath $stagePath -Destination $FullPolicyBackupPath -Force -ErrorAction Stop

        $snapshot = [ordered]@{
            SchemaVersion = 2
            ComputerName = $env:COMPUTERNAME
            CreatedUtc = [DateTime]::UtcNow.ToString('o')
            Profiles = @(Get-FirewallSnapshot)
            FullPolicyBackup = $metadata
        }
        Write-FirewallSnapshotFile -Snapshot $snapshot
        $committed = $true
    }
    catch {
        # If the new state manifest could not be committed, put the previous
        # WFW back so the old verified backup remains usable.
        if ($hadPrevious -and (Test-Path -LiteralPath $previousPath -PathType Leaf)) {
            Copy-Item -LiteralPath $previousPath -Destination $FullPolicyBackupPath -Force -ErrorAction SilentlyContinue
        }
        elseif (-not $hadPrevious -and (Test-Path -LiteralPath $FullPolicyBackupPath -PathType Leaf)) {
            Remove-Item -LiteralPath $FullPolicyBackupPath -Force -ErrorAction SilentlyContinue
        }
        throw
    }
    finally {
        foreach ($temporaryPath in @($stagePath,$previousPath)) {
            if (Test-Path -LiteralPath $temporaryPath -PathType Leaf) {
                Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
            }
        }
    }

    if (-not $committed) { throw 'The rulle.wfw backup was not committed.' }
    Write-Log ('Saved complete local firewall policy to ' + $FullPolicyBackupPath) 'INFO'
    Write-Host '[BACKUP SAVED] rulle.wfw contains the exported local firewall policy, including rules and profiles.' -ForegroundColor Green
    Write-Host ('File: ' + $FullPolicyBackupPath) -ForegroundColor Gray
    Write-Host ('SHA-256: ' + [string]$metadata.Sha256) -ForegroundColor Gray
}

function Restore-RulleFirewallPolicy {
    Ensure-StateDirectory
    $snapshot = Read-FirewallSnapshot
    if ([int]$snapshot.SchemaVersion -lt 2 -or -not $snapshot.FullPolicyBackup) {
        throw 'No complete .wfw backup is available. Select [1] Save rulle.wfw first.'
    }

    # Migrate a verified 0.7.5 backup to the requested filename without
    # changing its contents or losing the older backup file.
    if ([string]$snapshot.FullPolicyBackup.FileName -ne 'rulle.wfw') {
        $legacyPath = Join-Path $StateDirectory ([string]$snapshot.FullPolicyBackup.FileName)
        if (-not (Test-Path -LiteralPath $legacyPath -PathType Leaf)) {
            throw 'The saved firewall policy file is missing. No firewall settings were changed.'
        }
        Copy-Item -LiteralPath $legacyPath -Destination $FullPolicyBackupPath -Force -ErrorAction Stop
        $snapshot.FullPolicyBackup.FileName = 'rulle.wfw'
        Write-FirewallSnapshotFile -Snapshot $snapshot
        $snapshot = Read-FirewallSnapshot
    }

    $fullPath = $FullPolicyBackupPath
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        throw 'rulle.wfw was not found. Select [1] Save rulle.wfw first.'
    }
    $backupFile = Get-Item -LiteralPath $fullPath -ErrorAction Stop
    if ([long]$backupFile.Length -ne [long]$snapshot.FullPolicyBackup.Length) {
        throw 'rulle.wfw length verification failed. Restore was refused.'
    }
    $actualHash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256 -ErrorAction Stop).Hash
    if ($actualHash -ne [string]$snapshot.FullPolicyBackup.Sha256) {
        throw 'rulle.wfw SHA-256 verification failed. Restore was refused.'
    }

    $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    if (-not (Test-Path -LiteralPath $netsh -PathType Leaf)) { throw 'netsh.exe was not found. Restore is unavailable.' }

    # Keep a temporary recovery export of the currently active local policy.
    # It is automatically removed after successful restore and retained if rollback fails.
    $recoveryPath = Join-Path $StateDirectory ('rulle.recovery.' + [Guid]::NewGuid().ToString('N') + '.wfw')
    $recoveryCreated = $false
    $restoreVerified = $false
    Write-Host "`nRestoring rulle.wfw. The current local firewall rules and profile settings will be replaced." -ForegroundColor Yellow
    try {
        $null = Export-FullFirewallPolicyBackup -DestinationPath $recoveryPath
        $recoveryCreated = $true

        $nativeOutput = @(& $netsh advfirewall import $fullPath 2>&1)
        $importExitCode = $LASTEXITCODE
        if ($importExitCode -ne 0) {
            $detail = [string]::Join(' ', [string[]]$nativeOutput)
            throw ('netsh advfirewall import failed (exit ' + $importExitCode + '). ' + $detail)
        }

        # Verify the locally stored profile values and complete persistent rule inventory.
        $currentProfiles = @(Get-NetFirewallProfile -Profile $ProfilesToManage -PolicyStore PersistentStore -ErrorAction Stop)
        foreach ($saved in $snapshot.Profiles) {
            $actualProfile = $currentProfiles | Where-Object { $_.Name -eq $saved.Name } | Select-Object -First 1
            if (-not $actualProfile -or
                [string]$actualProfile.Enabled -ne [string]$saved.Enabled -or
                [string]$actualProfile.DefaultInboundAction -ne [string]$saved.DefaultInboundAction -or
                [string]$actualProfile.DefaultOutboundAction -ne [string]$saved.DefaultOutboundAction -or
                [string]$actualProfile.AllowLocalFirewallRules -ne [string]$saved.AllowLocalFirewallRules) {
                throw ('Restored local firewall profile verification failed for ' + $saved.Name + '.')
            }
        }

        $restoredInventory = Get-FirewallRuleInventorySnapshot
        if ([int]$restoredInventory.Count -ne [int]$snapshot.FullPolicyBackup.PersistentRuleCount -or
            [string]$restoredInventory.Sha256 -ne [string]$snapshot.FullPolicyBackup.PersistentRulesSha256) {
            throw ('Restored local rule inventory does not match rulle.wfw. Expected ' +
                $snapshot.FullPolicyBackup.PersistentRuleCount + ' rules; found ' + $restoredInventory.Count + '.')
        }
        $restoreVerified = $true
    }
    catch {
        $restoreError = $_.Exception.Message
        if ($recoveryCreated -and (Test-Path -LiteralPath $recoveryPath -PathType Leaf)) {
            Write-Host '[RECOVERY] Re-importing the local firewall policy that was active before this restore...' -ForegroundColor Yellow
            try {
                $rollbackOutput = @(& $netsh advfirewall import $recoveryPath 2>&1)
                $rollbackExit = $LASTEXITCODE
                if ($rollbackExit -eq 0) {
                    Write-Host '[RECOVERY IMPORTED] The pre-restore policy was re-imported.' -ForegroundColor Green
                }
                else {
                    Write-Host ('[RECOVERY WARNING] Rollback failed (exit ' + $rollbackExit + '). Recovery file retained: ' + $recoveryPath) -ForegroundColor Red
                    $recoveryCreated = $false
                }
            }
            catch {
                Write-Host ('[RECOVERY WARNING] Rollback failed: ' + $_.Exception.Message + '. Recovery file retained: ' + $recoveryPath) -ForegroundColor Red
                $recoveryCreated = $false
            }
        }
        throw ('rulle.wfw restore did not pass verification. Saved backup retained. ' + $restoreError)
    }
    finally {
        if ($restoreVerified -and $recoveryCreated -and (Test-Path -LiteralPath $recoveryPath -PathType Leaf)) {
            Remove-Item -LiteralPath $recoveryPath -Force -ErrorAction SilentlyContinue
        }
        elseif (-not $recoveryCreated -and (Test-Path -LiteralPath $recoveryPath -PathType Leaf)) {
            # A failed rollback deliberately retains this file for manual recovery.
        }
        elseif (-not $restoreVerified -and $recoveryCreated -and (Test-Path -LiteralPath $recoveryPath -PathType Leaf)) {
            Remove-Item -LiteralPath $recoveryPath -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Log 'rulle.wfw local firewall policy restore completed and verified.' 'INFO'
    Write-Host '[RESTORE VERIFIED] rulle.wfw restored: saved local firewall rules and profiles match.' -ForegroundColor Green
    Write-Host '[BACKUP RETAINED] rulle.wfw remains available for future restores.' -ForegroundColor Gray
}

function Show-FirewallPolicyBackupMenu {
    while ($true) {
        Write-Host "`nFIREWALL POLICY BACKUP / RESTORE" -ForegroundColor Cyan
        Write-Host '[1] Save current complete local firewall policy to rulle.wfw' -ForegroundColor Green
        Write-Host '[2] Restore complete local firewall policy from rulle.wfw' -ForegroundColor Yellow
        Write-Host '[Q] Return to main menu' -ForegroundColor Gray
        Write-Host 'Restore replaces the current local firewall rules and profile settings.' -ForegroundColor DarkYellow
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' {
                try { Save-RulleFirewallPolicy }
                catch { Write-Host ('[BACKUP ERROR] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('rulle.wfw save failed: ' + $_.Exception.Message) 'ERROR' }
            }
            '2' {
                try { Restore-RulleFirewallPolicy }
                catch { Write-Host ('[RESTORE ERROR] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('rulle.wfw restore failed: ' + $_.Exception.Message) 'ERROR' }
            }
            'Q' { return }
            default { Write-Host 'No action selected.' -ForegroundColor Gray }
        }
    }
}

function Start-StrictFirewall {
    Write-Host "`nWARNING: Strict mode blocks unmatched inbound AND outbound connections." -ForegroundColor Yellow
    Write-Host 'Applications without effective allow rules may lose network access.' -ForegroundColor Yellow
    Write-Host 'Local allow rules must be enabled for this script to manage its own rules.' -ForegroundColor Yellow
    # Selecting main-menu option [1] is the user's confirmation; no second APPLY prompt.
    Ensure-StateDirectory
    if (Test-Path -LiteralPath $StatePath -PathType Leaf) {
        # Preserve the original profile values and upgrade a legacy profile-only
        # snapshot with a full rules baseline captured once by this build.
        $existingSnapshot = Read-FirewallSnapshot
        if ([int]$existingSnapshot.SchemaVersion -lt 2) {
            $existingSnapshot = Upgrade-LegacyFirewallSnapshotToFull
        }
        Write-Host '[BACKUP] Existing verified full-policy baseline will be preserved.' -ForegroundColor Green
    }
    else {
        Save-FirewallSnapshot
        Write-Host ('[BACKUP] Original profile settings saved to ' + $StatePath) -ForegroundColor Green
        Write-Host ('[BACKUP] Complete local firewall policy and rules saved to ' + $FullPolicyBackupPath) -ForegroundColor Green
    }

    try {
        Set-NetFirewallProfile -Profile $ProfilesToManage -Enabled True `
            -DefaultInboundAction Block -DefaultOutboundAction Block `
            -AllowLocalFirewallRules True -ErrorAction Stop

        $current = @(Get-NetFirewallProfile -Profile $ProfilesToManage -ErrorAction Stop)
        foreach ($name in $ProfilesToManage) {
            $profile = $current | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            if (-not $profile -or [string]$profile.Enabled -ne 'True' -or
                [string]$profile.DefaultInboundAction -ne 'Block' -or
                [string]$profile.DefaultOutboundAction -ne 'Block' -or
                [string]$profile.AllowLocalFirewallRules -ne 'True') {
                throw ('Effective firewall policy verification failed for ' + $name + '. A Group Policy or other policy may override local settings.')
            }
        }
        Write-Log 'Strict firewall policy enabled and verified.' 'INFO'
        Write-Host '[FIREWALL VERIFIED] All three profiles enabled; inbound/outbound default Block; local rules merged.' -ForegroundColor Green
        return $true
    }
    catch {
        $applyError = $_.Exception.Message
        Write-Host ('[FIREWALL ERROR] ' + $applyError) -ForegroundColor Red
        Write-Warning 'Attempting to restore the saved pre-change profile settings.'
        try { Restore-FirewallSnapshot -KeepBackup }
        catch { Write-Host ('[ROLLBACK FAILED] ' + $_.Exception.Message) -ForegroundColor Red }
        Write-Log ('Strict firewall setup failed: ' + $applyError) 'ERROR'
        return $false
    }
}


function Normalize-FilterValue {
    param($Value, [ValidateSet('Generic','Protocol','Port','Address')][string]$Kind = 'Generic')
    $items = @($Value | ForEach-Object { [string]$_ } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if ($items.Count -eq 0) { return 'Any' }
    $normalized = @()
    foreach ($item in $items) {
        $mapped = $item
        if ($item -ieq 'Any' -or ($Kind -eq 'Protocol' -and $item -eq '256')) {
            $mapped = 'Any'
        }
        elseif ($Kind -eq 'Protocol') {
            switch -Regex ($item.ToUpperInvariant()) {
                '^(6|TCP)$'     { $mapped = 'TCP'; break }
                '^(17|UDP)$'    { $mapped = 'UDP'; break }
                '^(1|ICMPV4)$'  { $mapped = 'ICMPv4'; break }
                '^(58|ICMPV6)$' { $mapped = 'ICMPv6'; break }
                default         { $mapped = $item.ToUpperInvariant() }
            }
        }
        elseif ($Kind -eq 'Port') {
            $number = 0
            if ([int]::TryParse($item,[ref]$number) -and $number -ge 0 -and $number -le 65535) { $mapped = [string]$number }
            else { $mapped = $item.ToUpperInvariant() }
        }
        elseif ($Kind -eq 'Address') {
            $ip = $null
            if ([System.Net.IPAddress]::TryParse($item,[ref]$ip)) { $mapped = $ip.IPAddressToString.ToLowerInvariant() }
            else { $mapped = $item.ToLowerInvariant() }
        }
        else { $mapped = $item.ToLowerInvariant() }
        $normalized += [string]$mapped
    }
    return (($normalized | Sort-Object -Unique) -join ',')
}

function Normalize-FirewallProfile {
    param([string]$Profile)
    if ([string]::IsNullOrWhiteSpace($Profile)) { return 'Any' }
    $tokens = @($Profile -split '[,\s]+' | Where-Object { $_ } | ForEach-Object { $_.Trim() })
    $tokens = @($tokens | ForEach-Object { $_.ToUpperInvariant() })
    if ($tokens -contains 'ANY') { return 'Any' }
    $requiredProfiles = @('DOMAIN','PRIVATE','PUBLIC')
    $missingProfiles = @($requiredProfiles | Where-Object { $tokens -notcontains $_ })
    if ($missingProfiles.Count -eq 0) { return 'Any' }
    return (($tokens | ForEach-Object { $_.ToLowerInvariant() } | Sort-Object -Unique) -join ',')
}

function Test-ExactManagedRule {
    param($Rule, [hashtable]$Expected)
    try {
        $appFilter = Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop | Select-Object -First 1
        $portFilter = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop | Select-Object -First 1
        $addressFilter = Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop | Select-Object -First 1
        if (-not $appFilter -or -not $portFilter -or -not $addressFilter) { return $false }

        $expectedProtocol = if ($Expected.ContainsKey('Protocol')) { [string]$Expected.Protocol } else { 'Any' }
        $expectedRemotePort = if ($Expected.ContainsKey('RemotePort')) { [string]$Expected.RemotePort } else { 'Any' }
        $expectedRemoteAddress = if ($Expected.ContainsKey('RemoteAddress')) { [string]$Expected.RemoteAddress } else { 'Any' }
        $expectedProfile = if ($Expected.ContainsKey('Profile')) { [string]$Expected.Profile } else { 'Any' }

        $actualProgram = [Environment]::ExpandEnvironmentVariables([string]$appFilter.Program)
        $expectedProgram = [Environment]::ExpandEnvironmentVariables([string]$Expected.Program)
        return (
            [string]$Rule.Direction -eq [string]$Expected.Direction -and
            [string]$Rule.Action -eq [string]$Expected.Action -and
            ([string]$Rule.Enabled -eq 'True') -and
            (Normalize-FirewallProfile ([string]$Rule.Profile)) -eq (Normalize-FirewallProfile $expectedProfile) -and
            $actualProgram.Equals($expectedProgram,[StringComparison]::OrdinalIgnoreCase) -and
            (Normalize-FilterValue $portFilter.Protocol 'Protocol') -eq (Normalize-FilterValue $expectedProtocol 'Protocol') -and
            (Normalize-FilterValue $portFilter.RemotePort 'Port') -eq (Normalize-FilterValue $expectedRemotePort 'Port') -and
            (Normalize-FilterValue $addressFilter.RemoteAddress 'Address') -eq (Normalize-FilterValue $expectedRemoteAddress 'Address')
        )
    }
    catch { return $false }
}

function Find-EquivalentFirewallRule {
    param([Parameter(Mandatory=$true)][hashtable]$Expected)
    # Search effective policy and the local persistent store. Disabled rules also
    # count as existing: they are never re-enabled or rewritten by this script.
    $expectedProgram = [Environment]::ExpandEnvironmentVariables([string]$Expected.Program)
    $expectedProtocol = if ($Expected.ContainsKey('Protocol')) { [string]$Expected.Protocol } else { 'Any' }
    $expectedRemotePort = if ($Expected.ContainsKey('RemotePort')) { [string]$Expected.RemotePort } else { 'Any' }
    $expectedRemoteAddress = if ($Expected.ContainsKey('RemoteAddress')) { [string]$Expected.RemoteAddress } else { 'Any' }
    $expectedProfile = if ($Expected.ContainsKey('Profile')) { [string]$Expected.Profile } else { 'Any' }

    foreach ($store in @('ActiveStore','PersistentStore')) {
        try { $rules = @(Get-NetFirewallRule -PolicyStore $store -ErrorAction Stop) }
        catch { throw ('Cannot safely check firewall duplicates in ' + $store + ': ' + $_.Exception.Message) }

        foreach ($candidate in $rules) {
            if ([string]$candidate.Direction -ne [string]$Expected.Direction) { continue }
            if ([string]$candidate.Action -ne [string]$Expected.Action) { continue }
            if ((Normalize-FirewallProfile ([string]$candidate.Profile)) -ne (Normalize-FirewallProfile $expectedProfile)) { continue }

            try {
                $appFilter = Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $candidate -ErrorAction Stop | Select-Object -First 1
                if (-not $appFilter -or [string]::IsNullOrWhiteSpace([string]$appFilter.Program)) { continue }
                $actualProgram = [Environment]::ExpandEnvironmentVariables([string]$appFilter.Program)
                if (-not $actualProgram.Equals($expectedProgram,[StringComparison]::OrdinalIgnoreCase)) { continue }
                if ((Normalize-FilterValue $appFilter.Package 'Generic') -ne 'Any') { continue }

                $portFilter = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $candidate -ErrorAction Stop | Select-Object -First 1
                $addressFilter = Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $candidate -ErrorAction Stop | Select-Object -First 1
                $serviceFilter = Get-NetFirewallServiceFilter -AssociatedNetFirewallRule $candidate -ErrorAction Stop | Select-Object -First 1
                $interfaceFilter = Get-NetFirewallInterfaceFilter -AssociatedNetFirewallRule $candidate -ErrorAction Stop | Select-Object -First 1
                $interfaceTypeFilter = Get-NetFirewallInterfaceTypeFilter -AssociatedNetFirewallRule $candidate -ErrorAction Stop | Select-Object -First 1
                $securityFilter = Get-NetFirewallSecurityFilter -AssociatedNetFirewallRule $candidate -ErrorAction Stop | Select-Object -First 1
                if (-not $portFilter -or -not $addressFilter -or -not $serviceFilter -or -not $interfaceFilter -or -not $interfaceTypeFilter -or -not $securityFilter) {
                    throw 'Application matched but one or more associated firewall filters could not be read.'
                }

                # Only treat a rule as a duplicate when its other scope filters
                # also match the unrestricted defaults used by this script.
                $sameProtocol = (Normalize-FilterValue $portFilter.Protocol 'Protocol') -eq (Normalize-FilterValue $expectedProtocol 'Protocol')
                $sameRemotePort = (Normalize-FilterValue $portFilter.RemotePort 'Port') -eq (Normalize-FilterValue $expectedRemotePort 'Port')
                $sameLocalPort = (Normalize-FilterValue $portFilter.LocalPort 'Port') -eq 'Any'
                $sameIcmpType = (Normalize-FilterValue $portFilter.IcmpType 'Generic') -eq 'Any'
                $sameRemoteAddress = (Normalize-FilterValue $addressFilter.RemoteAddress 'Address') -eq (Normalize-FilterValue $expectedRemoteAddress 'Address')
                $sameLocalAddress = (Normalize-FilterValue $addressFilter.LocalAddress 'Address') -eq 'Any'
                $sameService = (Normalize-FilterValue $serviceFilter.Service 'Generic') -eq 'Any'
                $sameInterface = (Normalize-FilterValue $interfaceFilter.InterfaceAlias 'Generic') -eq 'Any'
                $sameInterfaceType = (Normalize-FilterValue $interfaceTypeFilter.InterfaceType 'Generic') -eq 'Any'
                $sameAuthentication = [string]$securityFilter.Authentication -eq 'NotRequired'
                $sameEncryption = [string]$securityFilter.Encryption -eq 'NotRequired'
                $sameOverride = [string]$securityFilter.OverrideBlockRules -eq 'False'
                $sameLocalUser = (Normalize-FilterValue $securityFilter.LocalUser 'Generic') -eq 'Any'
                $sameRemoteUser = (Normalize-FilterValue $securityFilter.RemoteUser 'Generic') -eq 'Any'
                $sameRemoteMachine = (Normalize-FilterValue $securityFilter.RemoteMachine 'Generic') -eq 'Any'
                if ($sameProtocol -and $sameRemotePort -and $sameLocalPort -and $sameIcmpType -and
                    $sameRemoteAddress -and $sameLocalAddress -and $sameService -and $sameInterface -and $sameInterfaceType -and
                    $sameAuthentication -and $sameEncryption -and $sameOverride -and $sameLocalUser -and $sameRemoteUser -and $sameRemoteMachine) {
                    return $candidate
                }
            }
            catch {
                throw ('Duplicate check was incomplete for existing rule "' + [string]$candidate.DisplayName + '" in ' + $store + '. No new rule was created. ' + $_.Exception.Message)
            }
        }
    }
    return $null
}

function Update-ManagedRuleCache {
    # One full PersistentStore read at startup and after our own changes. This is
    # intentionally not repeated for every event.
    $allRules = @(Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop)
    $cache = New-Object System.Collections.Generic.List[object]
    foreach ($rule in $allRules) {
        if ([string]$rule.Group -notin @($ManagedRuleGroup,$LegacyRuleGroup)) { continue }
        try {
            $app = Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
            $port = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
            $address = Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
            if (-not $app -or -not $port -or -not $address -or [string]::IsNullOrWhiteSpace([string]$app.Program)) { continue }
            $cache.Add([pscustomobject]@{
                Rule = $rule
                Program = [Environment]::ExpandEnvironmentVariables([string]$app.Program)
                Direction = [string]$rule.Direction
                Action = [string]$rule.Action
                Enabled = ([string]$rule.Enabled -eq 'True')
                Profile = Normalize-FirewallProfile ([string]$rule.Profile)
                Protocol = Normalize-FilterValue $port.Protocol 'Protocol'
                RemotePort = Normalize-FilterValue $port.RemotePort 'Port'
                RemoteAddress = Normalize-FilterValue $address.RemoteAddress 'Address'
                Description = [string]$rule.Description
            })
        }
        catch {
            Write-Log ('Could not inspect managed firewall rule ' + [string]$rule.DisplayName + ': ' + $_.Exception.Message) 'WARNING'
        }
    }
    $script:ManagedRuleCache = @($cache.ToArray())
    $script:ManagedRuleCacheReady = $true
    Write-Log ('Loaded ' + $script:ManagedRuleCache.Count + ' managed firewall rule(s) into the in-memory index.')
    return $script:ManagedRuleCache.Count
}

function Find-ManagedRuleForEvent {
    param(
        [string]$ProgramPath,
        [string]$Direction,
        [string]$RemoteAddress,
        [string]$RemotePort,
        [string]$Protocol
    )
    if (-not $script:ManagedRuleCacheReady) { Update-ManagedRuleCache | Out-Null }
    $program = [Environment]::ExpandEnvironmentVariables($ProgramPath)
    $address = Normalize-FilterValue $RemoteAddress 'Address'
    $protocolValue = Normalize-FilterValue $Protocol 'Protocol'
    $port = Normalize-FilterValue $RemotePort 'Port'

    foreach ($entry in $script:ManagedRuleCache) {
        if (-not $entry.Enabled -or $entry.Direction -ne $Direction -or $entry.Profile -ne 'Any') { continue }
        if (-not $entry.Program.Equals($program,[StringComparison]::OrdinalIgnoreCase)) { continue }
        $addressMatches = ($entry.RemoteAddress -eq 'Any' -or $entry.RemoteAddress -eq $address)
        $protocolMatches = ($entry.Protocol -eq 'Any' -or $entry.Protocol -eq $protocolValue)
        $portMatches = ($entry.RemotePort -eq 'Any' -or $entry.RemotePort -eq $port)
        if ($addressMatches -and $protocolMatches -and $portMatches) { return $entry }
    }
    return $null
}


function Get-ApplicationClassification {
    param([Parameter(Mandatory=$true)][string]$ProgramPath,[string]$SignatureStatus,[string]$SignerSubject)
    $full = [IO.Path]::GetFullPath($ProgramPath)
    $windowsRoot = if ($env:windir) { [IO.Path]::GetFullPath($env:windir).TrimEnd('\') + '\' } else { '' }
    $programRoots = @()
    if ($env:ProgramFiles) { $programRoots += ([IO.Path]::GetFullPath($env:ProgramFiles).TrimEnd('\') + '\') }
    if (${env:ProgramFiles(x86)}) { $programRoots += ([IO.Path]::GetFullPath(${env:ProgramFiles(x86)}).TrimEnd('\') + '\') }
    $userRoots = @()
    foreach ($candidate in @($env:USERPROFILE,$env:LOCALAPPDATA,$env:APPDATA,$env:TEMP,$env:TMP,$env:PUBLIC)) {
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) {
            try { $userRoots += ([IO.Path]::GetFullPath([string]$candidate).TrimEnd('\') + '\') } catch { }
        }
    }

    $locationClass = 'Other or custom location'
    if ($windowsRoot -and $full.StartsWith($windowsRoot,[StringComparison]::OrdinalIgnoreCase)) {
        $locationClass = 'Windows directory executable'
    }
    elseif (@($programRoots | Where-Object { $full.StartsWith($_,[StringComparison]::OrdinalIgnoreCase) }).Count -gt 0) {
        $locationClass = 'Installed application (Program Files)'
    }
    elseif (@($userRoots | Where-Object { $full.StartsWith($_,[StringComparison]::OrdinalIgnoreCase) }).Count -gt 0) {
        $locationClass = 'User-writable location (review carefully)'
    }

    if ($SignatureStatus -eq 'Valid' -and $SignerSubject -match '(?i)\bMicrosoft\b') {
        if ($locationClass -eq 'Windows directory executable') { return 'Microsoft-signed Windows component' }
        return 'Microsoft-signed application'
    }
    if ($SignatureStatus -ne 'Valid') { return ($locationClass + ' — signature not verified') }
    return ($locationClass + ' — signed by third-party publisher')
}

function Get-ApplicationTrustInfo {
    param([Parameter(Mandatory=$true)][string]$ProgramPath,[switch]$Refresh)
    if (-not (Test-Path -LiteralPath $ProgramPath -PathType Leaf)) { throw ('Executable no longer exists: ' + $ProgramPath) }
    $fullPath = [IO.Path]::GetFullPath($ProgramPath)
    $file = Get-Item -LiteralPath $fullPath -ErrorAction Stop
    $cacheKey = '{0}|{1}|{2}' -f $fullPath.ToLowerInvariant(),$file.Length,$file.LastWriteTimeUtc.Ticks
    if (-not $Refresh -and $script:ApplicationTrustCache.ContainsKey($cacheKey)) {
        return $script:ApplicationTrustCache[$cacheKey]
    }

    $hash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    $status = 'UnknownError'; $signer = ''; $thumbprint = ''; $statusMessage = ''
    try {
        $sig = Get-AuthenticodeSignature -FilePath $fullPath -ErrorAction Stop
        $status = [string]$sig.Status
        $statusMessage = [string]$sig.StatusMessage
        if ($sig.SignerCertificate) {
            $signer = [string]$sig.SignerCertificate.Subject
            $thumbprint = [string]$sig.SignerCertificate.Thumbprint
        }
    } catch { $status = 'UnknownError'; $statusMessage = $_.Exception.Message }

    $company = ''; $product = ''; $description = ''; $fileVersion = ''
    try {
        $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($fullPath)
        $company = [string]$version.CompanyName
        $product = [string]$version.ProductName
        $description = [string]$version.FileDescription
        $fileVersion = [string]$version.FileVersion
    } catch { }

    $classification = Get-ApplicationClassification -ProgramPath $fullPath -SignatureStatus $status -SignerSubject $signer
    $info = [pscustomobject]@{
        Program = $fullPath
        SHA256 = $hash
        SignatureStatus = $status
        SignatureStatusMessage = $statusMessage
        Publisher = $signer
        PublisherThumbprint = $thumbprint
        PublisherVerified = ($status -eq 'Valid')
        CompanyName = $company
        ProductName = $product
        FileDescription = $description
        FileVersion = $fileVersion
        Length = [long]$file.Length
        LastWriteTimeUtc = $file.LastWriteTimeUtc.ToString('o')
        Classification = $classification
    }
    $script:ApplicationTrustCache[$cacheKey] = $info
    return $info
}

function Get-RememberedDecisionIdentity {
    param(
        [string]$ProgramPath,[string]$ExecutableSHA256,[string]$Direction,
        [string]$RemoteAddress,[string]$RemotePort,[string]$Protocol
    )
    $normalizedPath = [Environment]::ExpandEnvironmentVariables($ProgramPath).ToLowerInvariant()
    $address = Normalize-FilterValue $RemoteAddress 'Address'
    $port = Normalize-FilterValue $RemotePort 'Port'
    $proto = Normalize-FilterValue $Protocol 'Protocol'
    $identity = @($normalizedPath,$ExecutableSHA256.ToUpperInvariant(),$Direction.ToUpperInvariant(),$address,$port,$proto) -join '|'
    return (Get-Sha256Hex -Text $identity)
}

function Read-RememberedDecisionStore {
    if (-not (Test-Path -LiteralPath $DecisionPath -PathType Leaf)) { return @() }
    $envelope = Get-Content -LiteralPath $DecisionPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace([string]$envelope.PayloadJson) -or [string]::IsNullOrWhiteSpace([string]$envelope.Sha256)) {
        throw 'Remembered-decision file is incomplete; it has not been used or overwritten.'
    }
    $actual = Get-Sha256Hex -Text ([string]$envelope.PayloadJson)
    if ($actual -ne [string]$envelope.Sha256) { throw 'Remembered-decision SHA-256 integrity check failed; file retained.' }
    $payload = [string]$envelope.PayloadJson | ConvertFrom-Json -ErrorAction Stop
    if ([int]$payload.SchemaVersion -ne 1 -or [string]$payload.ComputerName -ne [string]$env:COMPUTERNAME) {
        throw 'Remembered-decision schema or computer identity mismatch; file retained.'
    }
    $items = @($payload.Decisions)
    foreach ($item in $items) {
        if ([string]$item.Decision -ne 'Ignore' -or
            [string]$item.ExecutableSHA256 -notmatch '^[A-Fa-f0-9]{64}$' -or
            [string]$item.KeySHA256 -notmatch '^[A-Fa-f0-9]{64}$' -or
            [string]$item.Direction -notin @('Inbound','Outbound') -or
            [string]::IsNullOrWhiteSpace([string]$item.ProgramPath) -or
            [string]::IsNullOrWhiteSpace([string]$item.ExpiresUtc)) {
            throw 'Remembered-decision file contains an invalid entry; file retained.'
        }
    }
    return $items
}

function Save-RememberedDecisionStore {
    param([object[]]$Decisions)
    Ensure-StateDirectory
    # Refuse to overwrite an existing corrupt store.
    if (Test-Path -LiteralPath $DecisionPath -PathType Leaf) { $null = Read-RememberedDecisionStore }
    $payload = [ordered]@{
        SchemaVersion = 1
        ComputerName = $env:COMPUTERNAME
        UpdatedUtc = [DateTime]::UtcNow.ToString('o')
        Decisions = @($Decisions)
    }
    $payloadJson = ConvertTo-Json -InputObject $payload -Depth 8 -Compress
    $envelope = [ordered]@{ PayloadJson=$payloadJson; Sha256=(Get-Sha256Hex -Text $payloadJson) }
    $json = ConvertTo-Json -InputObject $envelope -Depth 4
    $tempPath = $DecisionPath + '.' + $PID + '.tmp'
    try {
        [IO.File]::WriteAllText($tempPath,$json,(New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tempPath -Destination $DecisionPath -Force -ErrorAction Stop
    }
    finally { if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue } }
}

function Find-RememberedIgnoreDecision {
    param([string]$ProgramPath,[string]$ExecutableSHA256,[string]$Direction,[string]$RemoteAddress,[string]$RemotePort,[string]$Protocol)
    $key = Get-RememberedDecisionIdentity @PSBoundParameters
    $now = [DateTimeOffset]::UtcNow
    foreach ($item in @(Read-RememberedDecisionStore)) {
        $expiry = [DateTimeOffset]::MinValue
        $styles = [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal
        if ([DateTimeOffset]::TryParse([string]$item.ExpiresUtc,[Globalization.CultureInfo]::InvariantCulture,$styles,[ref]$expiry) -and $expiry -gt $now -and [string]$item.KeySHA256 -eq $key) {
            return $item
        }
    }
    return $null
}

function Add-RememberedIgnoreDecision {
    param([string]$ProgramPath,[string]$ExecutableSHA256,[string]$Direction,[string]$RemoteAddress,[string]$RemotePort,[string]$Protocol,[int]$Days=7)
    if ($Days -lt 1 -or $Days -gt 365) { throw 'Remembered decision duration must be between 1 and 365 days.' }
    $items = @(Read-RememberedDecisionStore)
    $key = Get-RememberedDecisionIdentity -ProgramPath $ProgramPath -ExecutableSHA256 $ExecutableSHA256 -Direction $Direction -RemoteAddress $RemoteAddress -RemotePort $RemotePort -Protocol $Protocol
    $now = [DateTimeOffset]::UtcNow
    $keep = @()
    foreach ($item in $items) {
        $expiry = [DateTimeOffset]::MinValue
        $styles = [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal
        if ([DateTimeOffset]::TryParse([string]$item.ExpiresUtc,[Globalization.CultureInfo]::InvariantCulture,$styles,[ref]$expiry) -and $expiry -gt $now -and [string]$item.KeySHA256 -ne $key) { $keep += $item }
    }
    $keep += [pscustomobject]@{
        Decision='Ignore'; ProgramPath=[IO.Path]::GetFullPath($ProgramPath)
        ExecutableSHA256=$ExecutableSHA256.ToUpperInvariant(); Direction=$Direction
        RemoteAddress=(Normalize-FilterValue $RemoteAddress 'Address')
        RemotePort=(Normalize-FilterValue $RemotePort 'Port')
        Protocol=(Normalize-FilterValue $Protocol 'Protocol')
        KeySHA256=$key; CreatedUtc=$now.ToString('o'); ExpiresUtc=$now.AddDays($Days).ToString('o')
    }
    if ($keep.Count -gt 2000) { $keep = @($keep | Select-Object -Last 2000) }
    Save-RememberedDecisionStore -Decisions $keep
    Write-Log ('Remembered exact connection IGNORE decision for ' + $ProgramPath + ' until ' + $now.AddDays($Days).ToString('o'))
}

function Remove-ExpiredRememberedDecisions {
    $items = @(Read-RememberedDecisionStore)
    $now = [DateTimeOffset]::UtcNow
    $keep = @()
    $styles = [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal
    foreach ($item in $items) {
        $expiry = [DateTimeOffset]::MinValue
        if ([DateTimeOffset]::TryParse([string]$item.ExpiresUtc,[Globalization.CultureInfo]::InvariantCulture,$styles,[ref]$expiry) -and $expiry -gt $now) { $keep += $item }
    }
    $removed = $items.Count - $keep.Count
    if ($removed -gt 0) { Save-RememberedDecisionStore -Decisions $keep }
    return $removed
}

function Show-RememberedDecisionManager {
    $items = @(Read-RememberedDecisionStore)
    if ($items.Count -eq 0) { Write-Host 'No remembered connection decisions are saved.' -ForegroundColor Gray; return }
    Write-Host "`nREMEMBERED EXACT-CONNECTION IGNORE DECISIONS" -ForegroundColor Cyan
    for ($i=0; $i -lt $items.Count; $i++) {
        $item=$items[$i]
        Write-Host ('[{0}] {1} | {2} | {3} {4}:{5} | expires {6}' -f ($i+1),$item.ProgramPath,$item.Direction,$item.Protocol,$item.RemoteAddress,$item.RemotePort,$item.ExpiresUtc) -ForegroundColor Gray
    }
    $selection=(Read-Host 'Enter a number to forget, type CLEAR to forget all, or press Enter to return').Trim()
    if ([string]::IsNullOrWhiteSpace($selection)) { return }
    if ($selection -ceq 'CLEAR') {
        $confirm=Read-Host 'Type DELETE to clear all remembered decisions'
        if ($confirm -ceq 'DELETE') { Save-RememberedDecisionStore -Decisions @(); Write-Host '[CLEARED] Remembered decisions removed.' -ForegroundColor Green }
        return
    }
    $index=0
    if (-not [int]::TryParse($selection,[ref]$index) -or $index -lt 1 -or $index -gt $items.Count) { Write-Host 'Invalid selection.' -ForegroundColor Yellow; return }
    $confirm=Read-Host 'Type DELETE to forget this decision'
    if ($confirm -ceq 'DELETE') {
        $remaining=@(); for($i=0;$i -lt $items.Count;$i++){if($i -ne ($index-1)){$remaining += $items[$i]}}
        Save-RememberedDecisionStore -Decisions $remaining
        Write-Host '[REMOVED] Remembered decision deleted.' -ForegroundColor Green
    }
}


function Export-RunningProcessFingerprints {
    Ensure-StateDirectory
    $outDir = Join-Path $StateDirectory 'Fingerprints'
    if (-not (Test-Path -LiteralPath $outDir)) {
        New-Item -Path $outDir -ItemType Directory -Force -ErrorAction Stop | Out-Null
    }
    & icacls.exe $outDir '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Could not restrict permissions on the fingerprint output directory.' }

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $rows = New-Object System.Collections.Generic.List[object]
    $hashByPath = @{}
    $processes = @(Get-Process -ErrorAction SilentlyContinue | Sort-Object Id)
    $total = $processes.Count
    $done = 0

    foreach ($process in $processes) {
        $done++
        $path = ''
        $hash = ''
        $status = 'UNAVAILABLE'
        $length = $null
        $lastWrite = ''
        try {
            $path = [string]$process.Path
            if ([string]::IsNullOrWhiteSpace($path)) {
                $status = 'PATH_UNAVAILABLE (access denied, protected process, or process exited)'
            }
            elseif (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
                $status = 'FILE_MISSING_OR_PROCESS_EXITED'
            }
            else {
                $full = [IO.Path]::GetFullPath($path)
                $key = $full.ToLowerInvariant()
                if (-not $hashByPath.ContainsKey($key)) {
                    $file = Get-Item -LiteralPath $full -ErrorAction Stop
                    $digest = (Get-FileHash -LiteralPath $full -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
                    $hashByPath[$key] = [pscustomobject]@{
                        SHA256 = $digest
                        Length = [long]$file.Length
                        LastWriteTimeUtc = $file.LastWriteTimeUtc.ToString('o')
                    }
                }
                $cached = $hashByPath[$key]
                $hash = [string]$cached.SHA256
                $length = [long]$cached.Length
                $lastWrite = [string]$cached.LastWriteTimeUtc
                $status = 'HASHED'
            }
        }
        catch {
            $status = 'HASH_ERROR: ' + $_.Exception.Message
        }

        $rows.Add([pscustomobject]@{
            ScanUtc = [DateTime]::UtcNow.ToString('o')
            PID = [int]$process.Id
            ProcessName = [string]$process.ProcessName
            ExecutablePath = $path
            SHA256 = $hash
            FileLength = $length
            LastWriteTimeUtc = $lastWrite
            Status = $status
        })
        if (($done % 25) -eq 0 -or $done -eq $total) {
            Write-Progress -Activity 'Fingerprinting running processes' -Status ("$done of $total processes") -PercentComplete ([int](100*$done/[Math]::Max(1,$total)))
        }
    }
    Write-Progress -Activity 'Fingerprinting running processes' -Completed

    $jsonPath = Join-Path $outDir ('RunningProcessFingerprints-{0}.json' -f $stamp)
    $csvPath = Join-Path $outDir ('RunningProcessFingerprints-{0}.csv' -f $stamp)
    $jsonTemp = $jsonPath + '.' + $PID + '.tmp'
    $csvTemp = $csvPath + '.' + $PID + '.tmp'
    try {
        $json = ConvertTo-Json -InputObject @($rows.ToArray()) -Depth 5
        [IO.File]::WriteAllText($jsonTemp,$json,(New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $jsonTemp -Destination $jsonPath -ErrorAction Stop
        $rows.ToArray() | Export-Csv -LiteralPath $csvTemp -NoTypeInformation -Encoding UTF8 -ErrorAction Stop
        Move-Item -LiteralPath $csvTemp -Destination $csvPath -ErrorAction Stop
    }
    finally {
        foreach ($tempPath in @($jsonTemp,$csvTemp)) {
            if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
        }
    }

    $hashed = @($rows | Where-Object { $_.Status -eq 'HASHED' }).Count
    $unavailable = $rows.Count - $hashed
    Write-Host "`nRUNNING PROCESS SHA-256 INVENTORY" -ForegroundColor Cyan
    Write-Host ('Processes observed:       ' + $rows.Count) -ForegroundColor Gray
    Write-Host ('Processes with SHA-256:   ' + $hashed) -ForegroundColor Green
    Write-Host ('Unavailable / failed:     ' + $unavailable) -ForegroundColor Yellow
    Write-Host ('JSON report:               ' + $jsonPath) -ForegroundColor Gray
    Write-Host ('CSV report:                ' + $csvPath) -ForegroundColor Gray
    Write-Host 'Note: inaccessible/protected processes are recorded with a status; they are not silently omitted.' -ForegroundColor DarkYellow
    Write-Log ('Saved running-process SHA-256 inventory. Hashed='+$hashed+'; unavailable='+$unavailable)
    return [pscustomobject]@{ Total=$rows.Count; Hashed=$hashed; Unavailable=$unavailable; JsonPath=$jsonPath; CsvPath=$csvPath }
}

function Show-ApplicationIntelligenceMenu {
    while ($true) {
        Write-Host "`nAPPLICATION INTELLIGENCE" -ForegroundColor Cyan
        Write-Host '[1] Inspect executable: SHA-256, publisher, signature and classification' -ForegroundColor Green
        Write-Host '[2] Review / remove remembered exact-connection decisions' -ForegroundColor Gray
        Write-Host '[3] SHA-256 inventory of ALL running processes (save CSV + JSON)' -ForegroundColor Cyan
        Write-Host '[Q] Return to main menu' -ForegroundColor Gray
        $choice=(Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' {
                $path=(Read-Host 'Enter full executable path (blank to cancel)').Trim().Trim('"')
                if ([string]::IsNullOrWhiteSpace($path)) { continue }
                try {
                    $info=Get-ApplicationTrustInfo -ProgramPath $path -Refresh
                    Write-Host "`nAPPLICATION FINGERPRINT" -ForegroundColor Cyan
                    Write-Host ('Path:             ' + $info.Program) -ForegroundColor Gray
                    Write-Host ('SHA-256:          ' + $info.SHA256) -ForegroundColor White
                    Write-Host ('Authenticode:     ' + $info.SignatureStatus) -ForegroundColor $(if($info.PublisherVerified){'Green'}else{'Yellow'})
                    Write-Host ('Publisher:        ' + $(if($info.Publisher){$info.Publisher}else{'(not available)'}) ) -ForegroundColor Gray
                    Write-Host ('Publisher cert:   ' + $(if($info.PublisherThumbprint){$info.PublisherThumbprint}else{'(not available)'}) ) -ForegroundColor Gray
                    Write-Host ('Company:          ' + $info.CompanyName) -ForegroundColor Gray
                    Write-Host ('Product:          ' + $info.ProductName) -ForegroundColor Gray
                    Write-Host ('File description: ' + $info.FileDescription) -ForegroundColor Gray
                    Write-Host ('Version:          ' + $info.FileVersion) -ForegroundColor Gray
                    Write-Host ('Classification:   ' + $info.Classification) -ForegroundColor Yellow
                    Write-Host 'Classification is a path/signature heuristic, not a malware verdict or application reputation score.' -ForegroundColor DarkYellow
                } catch { Write-Host ('[APPLICATION INSPECTION ERROR] ' + $_.Exception.Message) -ForegroundColor Red }
                $null=Read-Host 'Press Enter to continue'
            }
            '2' {
                try { Show-RememberedDecisionManager } catch { Write-Host ('[DECISION STORE ERROR] '+$_.Exception.Message) -ForegroundColor Red }
                $null=Read-Host 'Press Enter to continue'
            }
            '3' {
                try { $null = Export-RunningProcessFingerprints }
                catch { Write-Host ('[PROCESS FINGERPRINT ERROR] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('Process fingerprint inventory failed: ' + $_.Exception.Message) 'ERROR' }
                $null=Read-Host 'Press Enter to return to Application Intelligence'
            }
            'Q' { return }
            default { Write-Host 'Invalid option.' -ForegroundColor Gray }
        }
    }
}

function New-ManagedRuleDescription {
    param($TrustInfo,$ExpiresUtc,[ValidateSet('Allow','Block')][string]$Action='Allow')

    # Windows Firewall rejects some description characters in rule metadata.
    # Use a short, plain-ASCII format (letters, digits, spaces and hyphens only).
    # The previous pipe/equals/colon-delimited format is still recognized by
    # the read-only metadata parsers below for compatibility with older rules.
    $expiry = 'NEVER'
    if ($null -ne $ExpiresUtc) {
        $expiry = ([DateTimeOffset]$ExpiresUtc).ToUniversalTime().ToString("yyyyMMdd'T'HHmmss'Z'",[Globalization.CultureInfo]::InvariantCulture)
    }

    $hash = 'NONE'
    $signature = 'NOTAPPLICABLE'
    if ($null -ne $TrustInfo) {
        $candidateHash = [string]$TrustInfo.SHA256
        if ($candidateHash -match '^[A-Fa-f0-9]{64}$') { $hash = $candidateHash.ToUpperInvariant() }
        $candidateSignature = [string]$TrustInfo.SignatureStatus
        if (-not [string]::IsNullOrWhiteSpace($candidateSignature)) {
            $signature = ($candidateSignature -replace '[^A-Za-z0-9-]','')
            if ([string]::IsNullOrWhiteSpace($signature)) { $signature = 'UNKNOWN' }
            if ($signature.Length -gt 24) { $signature = $signature.Substring(0,24) }
            $signature = $signature.ToUpperInvariant()
        }
    }

    $description = 'ZT-MANAGED ACTION-{0} SHA256-{1} SIG-{2} EXPIRES-{3}' -f $Action.ToUpperInvariant(),$hash,$signature,$expiry
    if ($description.Length -gt 192 -or $description -notmatch '^[A-Za-z0-9 -]+$') {
        throw 'Generated firewall rule description failed the safe ASCII/length check.'
    }
    return $description
}

function ConvertFrom-ManagedExpiryTimestamp {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    $styles = [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal
    $parsed = [DateTimeOffset]::MinValue
    $culture = [Globalization.CultureInfo]::InvariantCulture
    if ([DateTimeOffset]::TryParseExact($Value,"yyyyMMdd'T'HHmmss'Z'",$culture,$styles,[ref]$parsed)) { return $parsed }
    # Read-only compatibility with earlier ISO-8601 metadata.
    if ([DateTimeOffset]::TryParse($Value,$culture,$styles,[ref]$parsed)) { return $parsed }
    return $null
}

function Get-ExpiredManagedRules {
    # Read-only: expiration timestamps are reported but existing firewall rules
    # are never removed automatically.
    $now = [DateTimeOffset]::UtcNow
    $expired = 0
    $rules = @(Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop | Where-Object { [string]$_.Group -in @($ManagedRuleGroup,$LegacyRuleGroup) })
    foreach ($rule in $rules) {
        $description = [string]$rule.Description
        $expiryMatch = [regex]::Match($description,'(?:^|[\s|])EXPIRES(?:=|-)([^\s|]+)')
        if (-not $expiryMatch.Success) { continue }
        $expiryText = [string]$expiryMatch.Groups[1].Value
        if ($expiryText -eq 'NEVER') { continue }
        $expiry = ConvertFrom-ManagedExpiryTimestamp -Value $expiryText
        if ($null -eq $expiry) {
            Write-Log ('Invalid expiration metadata; retained rule unchanged: ' + $rule.DisplayName) 'WARNING'
            continue
        }
        if ($expiry -le $now) {
            $expired++
            Write-Log ('Temporary rule has passed its recorded expiry and was retained unchanged: ' + $rule.DisplayName) 'WARNING'
            Write-Host ('[EXPIRED - LEFT UNCHANGED] ' + $rule.DisplayName) -ForegroundColor Yellow
        }
    }
    return $expired
}

function Test-ManagedRuleIntegrity {
    # Read-only: report a changed/missing executable, but never disable its rule.
    if (-not $script:ManagedRuleCacheReady) { Update-ManagedRuleCache | Out-Null }
    $hashCache = @{}
    $warnings = 0
    foreach ($entry in @($script:ManagedRuleCache)) {
        if ($entry.Action -ne 'Allow' -or -not $entry.Enabled) { continue }
        if ($entry.Description -notmatch '(?:^|[\s|])SHA256(?:=|-)([A-Fa-f0-9]{64})(?=[\s|]|$)') { continue }
        $approvedHash = $Matches[1].ToUpperInvariant()
        $key = $entry.Program.ToLowerInvariant()
        if (-not $hashCache.ContainsKey($key)) {
            try {
                if (Test-Path -LiteralPath $entry.Program -PathType Leaf) { $hashCache[$key] = (Get-FileHash -LiteralPath $entry.Program -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant() }
                else { $hashCache[$key] = 'MISSING' }
            }
            catch { $hashCache[$key] = 'ERROR' }
        }
        $current = [string]$hashCache[$key]
        if ($current -ne $approvedHash) {
            $warnings++
            $reason = if ($current -eq 'MISSING') { 'file missing' } elseif ($current -eq 'ERROR') { 'hash failed' } else { 'SHA-256 changed' }
            Write-Log ('Executable integrity warning; firewall rule left unchanged (' + $reason + '): ' + $entry.Program) 'WARNING'
            Write-Host ('[INTEGRITY WARNING - RULE LEFT UNCHANGED] ' + $entry.Program + ' (' + $reason + ')') -ForegroundColor Red
        }
    }
    return $warnings
}

function Invoke-ZeroTrustMaintenance {
    Write-Host "`nREAD-ONLY MANAGED RULE HEALTH" -ForegroundColor Cyan
    $expired = 0
    $integrityWarnings = 0
    $count = 0
    try {
        $expired = Get-ExpiredManagedRules
    }
    catch {
        Write-Host ('[EXPIRY AUDIT ERROR] ' + $_.Exception.Message) -ForegroundColor Red
        Write-Log ('Expiry audit failed: ' + $_.Exception.Message) 'ERROR'
    }
    try {
        $integrityWarnings = Test-ManagedRuleIntegrity
    }
    catch {
        Write-Host ('[EXECUTABLE INTEGRITY AUDIT ERROR] ' + $_.Exception.Message) -ForegroundColor Red
        Write-Log ('Executable integrity audit failed: ' + $_.Exception.Message) 'ERROR'
    }
    try {
        $rememberedExpired = Remove-ExpiredRememberedDecisions
        Write-Host ('Expired remembered connection decisions cleaned from the local decision store: ' + $rememberedExpired) -ForegroundColor Gray
    }
    catch {
        Write-Host ('[DECISION MEMORY CLEANUP ERROR] ' + $_.Exception.Message) -ForegroundColor Red
        Write-Log ('Remembered-decision cleanup failed: ' + $_.Exception.Message) 'ERROR'
    }
    try { $count = Update-ManagedRuleCache }
    catch {
        Write-Host ('[RULE INDEX ERROR] ' + $_.Exception.Message) -ForegroundColor Red
        Write-Log ('Managed rule index refresh failed: ' + $_.Exception.Message) 'ERROR'
    }
    Write-Host ('Expired temporary rules identified and retained unchanged: ' + $expired) -ForegroundColor Gray
    Write-Host ('Executable-integrity warnings (rules retained unchanged): ' + $integrityWarnings) -ForegroundColor Gray
    Write-Host ('Managed rules currently indexed: ' + $count) -ForegroundColor Gray
    Write-Host 'This script does not modify, disable, re-enable, or delete existing firewall rules.' -ForegroundColor Yellow
    Write-Host 'Executable hashes are local integrity checks, not proof that an application is safe.' -ForegroundColor Yellow
    Write-Host 'Read-only maintenance finished.' -ForegroundColor Green
}

function Start-CaptureUtility {
    try {
        if (-not (Test-Path -LiteralPath $Pktmon -PathType Leaf)) {
            Write-Host 'pktmon.exe was not found. Packet capture is unavailable on this Windows installation.' -ForegroundColor Yellow
            return
        }
        Ensure-CaptureDirectory
        Show-ZTCaptureMenu
    }
    catch {
        Write-Host ('[CAPTURE ERROR] ' + $_.Exception.Message) -ForegroundColor Red
        Write-Log ('Capture menu failed: ' + $_.Exception.Message) 'ERROR'
    }
}

function Show-DnsEncryptionAudit {
    Write-Host "`nDNS ENCRYPTION CONFIGURATION AUDIT (READ-ONLY)" -ForegroundColor Cyan
    $dnsRows = @()
    $doh = @()
    try {
        if (-not (Get-Command Get-NetAdapter -ErrorAction SilentlyContinue)) {
            throw 'Get-NetAdapter is unavailable. The Windows NetAdapter module may be missing.'
        }
        if (-not (Get-Command Get-DnsClientServerAddress -ErrorAction SilentlyContinue)) {
            throw 'Get-DnsClientServerAddress is unavailable. The Windows DnsClient module may be missing.'
        }
        Import-Module NetAdapter -ErrorAction Stop
        Import-Module DnsClient -ErrorAction Stop
        $upIndexes = @(Get-NetAdapter -ErrorAction Stop |
            Where-Object { [string]$_.Status -eq 'Up' } |
            ForEach-Object { [int]$_.InterfaceIndex } |
            Select-Object -Unique)
        $dnsRows = @(Get-DnsClientServerAddress -ErrorAction Stop |
            Where-Object { $upIndexes -contains [int]$_.InterfaceIndex -and @($_.ServerAddresses).Count -gt 0 })
    }
    catch {
        Write-Host ('[DNS ADAPTER ENUMERATION ERROR] ' + $_.Exception.Message) -ForegroundColor Yellow
        Write-Log ('DNS adapter enumeration failed: ' + $_.Exception.Message) 'WARNING'
    }

    $dohCommand = Get-Command Get-DnsClientDohServerAddress -ErrorAction SilentlyContinue
    if ($dohCommand) {
        try { $doh = @(Get-DnsClientDohServerAddress -ErrorAction Stop) }
        catch {
            Write-Host ('[DoH MAPPING QUERY ERROR] ' + $_.Exception.Message) -ForegroundColor Yellow
            Write-Log ('DoH mapping query failed: ' + $_.Exception.Message) 'WARNING'
        }
    }
    else {
        Write-Host 'This Windows build does not expose Get-DnsClientDohServerAddress; DoH mappings cannot be inspected with this cmdlet.' -ForegroundColor Yellow
    }

    if ($dnsRows.Count -eq 0) {
        Write-Host 'No DNS servers were reported on network adapters currently Up.' -ForegroundColor Yellow
    }
    foreach ($row in $dnsRows) {
        foreach ($server in @($row.ServerAddresses)) {
            $mapping = $doh | Where-Object { [string]$_.ServerAddress -eq [string]$server } | Select-Object -First 1
            if (-not $mapping) {
                Write-Host ('{0} | {1} | NO DoH MAPPING FOUND' -f $row.InterfaceAlias,$server) -ForegroundColor Yellow
                continue
            }
            $propertyNames = @($mapping.PSObject.Properties | ForEach-Object { $_.Name })
            $hasAuto = $propertyNames -contains 'AutoUpgrade'
            $hasFallback = $propertyNames -contains 'AllowFallbackToUdp'
            $hasTemplate = $propertyNames -contains 'DohTemplate'
            if (-not ($hasAuto -and $hasFallback -and $hasTemplate)) {
                Write-Host ('{0} | {1} | INCOMPLETE DoH MAPPING DATA' -f $row.InterfaceAlias,$server) -ForegroundColor Yellow
                continue
            }
            $auto = [bool]$mapping.AutoUpgrade
            $fallback = [bool]$mapping.AllowFallbackToUdp
            $template = [string]$mapping.DohTemplate
            $configured = ($auto -and -not $fallback -and $template -like 'https://*')
            if ($configured) {
                $label = 'DoH policy configured; packet-level encryption not proven'
                $color = 'Green'
            }
            elseif ($auto -and $fallback) {
                $label = 'DoH enabled; plaintext UDP fallback allowed'
                $color = 'Yellow'
            }
            elseif (-not $auto) {
                $label = 'Template present; AutoUpgrade disabled'
                $color = 'Yellow'
            }
            else {
                $label = 'DoH configuration needs review'
                $color = 'Yellow'
            }
            Write-Host ('{0} | {1} | {2}' -f $row.InterfaceAlias,$server,$label) -ForegroundColor $color
            Write-Host ('    Template={0}; AutoUpgrade={1}; AllowFallbackToUdp={2}' -f $template,$auto,$fallback) -ForegroundColor Gray
        }
    }

    Write-Host "`nDEFAULT WINDOWS DNS CLIENT RESOLUTION PROBE (READ-ONLY)" -ForegroundColor Cyan
    if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
        try {
            $probeName = 'www.microsoft.com'
            $probeResults = @(Resolve-DnsName -Name $probeName -Type A -DnsOnly -ErrorAction Stop)
            $probeAddresses = @($probeResults |
                Where-Object { [string]$_.Type -eq 'A' } |
                ForEach-Object { [string]$_.IPAddress } |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
                Select-Object -Unique)
            if ($probeAddresses.Count -gt 0) {
                Write-Host ('Default resolver probe succeeded: {0} -> {1}' -f $probeName,($probeAddresses -join ', ')) -ForegroundColor Green
            }
            else {
                Write-Host 'Probe completed but returned no A records.' -ForegroundColor Yellow
            }
            Write-Host 'Uses the normal Windows resolver path. With VPNs, multiple interfaces, NRPT or proxies, it cannot identify one unique upstream server.' -ForegroundColor Gray
        }
        catch { Write-Host ('Default resolver probe failed: ' + $_.Exception.Message) -ForegroundColor Yellow }
    }
    else {
        Write-Host 'Resolve-DnsName is unavailable; DNS resolution probe was skipped.' -ForegroundColor Yellow
    }
    Write-Host 'Configuration is not packet-level proof. Use the integrated pktmon capture menu to inspect observed traffic.' -ForegroundColor Cyan
}
function New-ZeroTrustFirewallRule {
    param([Parameter(Mandatory=$true)][hashtable]$RuleParameters)
    try {
        # Do not rely only on our own Group/cache: scan all effective and saved
        # firewall rules, including disabled rules and rules created elsewhere.
        $equivalent = Find-EquivalentFirewallRule -Expected $RuleParameters
        if ($equivalent) {
            $enabledState = [string]$equivalent.Enabled
            Write-Host ('  [SKIPPED - EQUIVALENT FIREWALL RULE EXISTS; LEFT UNCHANGED] ' + [string]$equivalent.DisplayName + ' | Enabled=' + $enabledState + ' | Group=' + [string]$equivalent.Group) -ForegroundColor DarkYellow
            return [pscustomobject]@{Status='AlreadyExists';Rule=$equivalent;Message='Equivalent rule already exists in ActiveStore or PersistentStore; existing rule was not changed.'}
        }

        # A stable-name collision is never repaired, overwritten, re-enabled,
        # or deleted. It blocks creation instead.
        foreach ($store in @('ActiveStore','PersistentStore')) {
            # Do not use Get-NetFirewallRule -Name with -ErrorAction Stop here:
            # Windows reports a terminating "no objects found" error when a
            # genuinely new name has no match. Enumerate successfully, then filter;
            # an empty result is the normal case and must allow rule creation.
            $storeRules = @(Get-NetFirewallRule -PolicyStore $store -ErrorAction Stop)
            $named = @($storeRules | Where-Object { [string]$_.Name -eq [string]$RuleParameters.Name })
            if ($named.Count -gt 0) {
                throw ('Rule-name collision in ' + $store + ': ' + $RuleParameters.Name + '. Existing rule was left unchanged; no new rule was created.')
            }
        }

        New-NetFirewallRule -PolicyStore PersistentStore @RuleParameters -ErrorAction Stop | Out-Null
        $created = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name $RuleParameters.Name -ErrorAction Stop)
        if ($created.Count -ne 1) { throw 'Persistent rule read-back did not return exactly one rule.' }
        if ([string]$created[0].Group -ne $ManagedRuleGroup) { throw 'Saved rule group did not match.' }
        if (-not (Test-ExactManagedRule -Rule $created[0] -Expected $RuleParameters)) { throw 'Saved rule filters did not match requested settings.' }
        Update-ManagedRuleCache | Out-Null
        Write-Host ('  [NEW RULE CREATED AND VERIFIED] ' + $RuleParameters.DisplayName) -ForegroundColor Green
        return [pscustomobject]@{Status='Created';Rule=$created[0];Message='A genuinely new rule was saved and verified.'}
    }
    catch {
        $detail = $_.Exception.Message
        $category = [string]$_.CategoryInfo
        $errorId = [string]$_.FullyQualifiedErrorId
        $after = @()
        try {
            $savedRulesAfterAttempt = @(Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop)
            $after = @($savedRulesAfterAttempt | Where-Object { [string]$_.Name -eq [string]$RuleParameters.Name })
        }
        catch { Write-Log ('Post-failure rule read-back also failed: ' + $_.Exception.Message) 'ERROR' }

        foreach ($candidate in $after) {
            if ([string]$candidate.Group -eq $ManagedRuleGroup -and (Test-ExactManagedRule -Rule $candidate -Expected $RuleParameters)) {
                try { Update-ManagedRuleCache | Out-Null } catch { $script:ManagedRuleCacheReady = $false }
                Write-Host ('  [MATCHING RULE EXISTS - NO FURTHER CHANGES] ' + $RuleParameters.DisplayName) -ForegroundColor DarkYellow
                return [pscustomobject]@{Status='AlreadyExists';Rule=$candidate;Message='A matching rule exists after the creation attempt; it was not modified.'}
            }
        }
        $diagnostic = $detail
        if ($category) { $diagnostic += ' | Category: ' + $category }
        if ($errorId) { $diagnostic += ' | ErrorId: ' + $errorId }
        Write-Host ('  [NO RULE CREATED / EXISTING RULES UNCHANGED] ' + $diagnostic) -ForegroundColor Red
        Write-Log ('Firewall rule creation skipped or failed for ' + $RuleParameters.Name + ': ' + $diagnostic) 'ERROR'
        return [pscustomobject]@{Status='Failed';Rule=$null;Message=$diagnostic}
    }
}

function Get-RuleHash {
    param([string]$Text)
    return (Get-Sha256Hex -Text $Text).Substring(0,16).ToLowerInvariant()
}

function Convert-DeviceApplicationPath {
    param([string]$RawPath)
    if ([string]::IsNullOrWhiteSpace($RawPath) -or $RawPath -eq 'System') { return $null }
    $candidate = $RawPath.Trim()

    if ($candidate.StartsWith('\??\', [StringComparison]::OrdinalIgnoreCase)) {
        $candidate = $candidate.Substring(4)
    }
    if ($candidate.StartsWith('\SystemRoot\', [StringComparison]::OrdinalIgnoreCase)) {
        $candidate = Join-Path $env:SystemRoot $candidate.Substring(12)
    }

    if ($candidate -match '^\\Device\\') {
        if (-not ('ZeroTrustDevicePathResolver' -as [type])) {
            $typeDefinition = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class ZeroTrustDevicePathResolver {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern uint QueryDosDevice(string lpDeviceName, StringBuilder lpTargetPath, int ucchMax);
}
'@
            Add-Type -TypeDefinition $typeDefinition -ErrorAction Stop
        }
        foreach ($drive in [System.IO.Directory]::GetLogicalDrives()) {
            $letter = $drive.TrimEnd('\')
            $buffer = New-Object System.Text.StringBuilder 1024
            $result = [ZeroTrustDevicePathResolver]::QueryDosDevice($letter,$buffer,$buffer.Capacity)
            if ($result -gt 0) {
                $targets = $buffer.ToString().Split([char]0,[StringSplitOptions]::RemoveEmptyEntries)
                foreach ($target in $targets) {
                    if ($candidate.StartsWith($target,[StringComparison]::OrdinalIgnoreCase)) {
                        $candidate = $letter + $candidate.Substring($target.Length)
                        break
                    }
                }
            }
            if ($candidate -notmatch '^\\Device\\') { break }
        }
    }

    if ($candidate -match '^[A-Za-z]:\\' -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        try { return [System.IO.Path]::GetFullPath($candidate) } catch { return $candidate }
    }
    return $null
}

function Convert-ProtocolNumber {
    param([string]$Number)
    switch ($Number) {
        '6'  { return 'TCP' }
        '17' { return 'UDP' }
        '1'  { return 'ICMPv4' }
        '58' { return 'ICMPv6' }
        default {
            $n = 0
            if ([int]::TryParse($Number,[ref]$n) -and $n -ge 0 -and $n -le 255) { return [string]$n }
            return $null
        }
    }
}

function Get-EventFieldMap {
    param($EventRecord)
    $map = @{}
    $xml = [xml]$EventRecord.ToXml()
    foreach ($item in $xml.Event.EventData.Data) {
        if ($item.Name) { $map[[string]$item.Name] = [string]$item.InnerText }
    }
    return $map
}

function ConvertTo-FirewallRuleDisplayValue {
    param($Value)
    if ($null -eq $Value) { return 'Any' }
    $items = @($Value | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($items.Count -eq 0) { return 'Any' }
    return ($items -join ', ')
}

function Show-AllFirewallRules {
    try {
        # ActiveStore is the effective resultant policy: local rules plus all
        # applicable policy stores, including Group Policy. This is read-only.
        $allRules = @(Get-NetFirewallRule -PolicyStore ActiveStore -TracePolicyStore -ErrorAction Stop |
            Sort-Object DisplayGroup,DisplayName,Name)
        if ($allRules.Count -eq 0) {
            Write-Host 'Windows returned no rules from ActiveStore.' -ForegroundColor Gray
            return
        }

        Write-Host "`nALL EFFECTIVE WINDOWS FIREWALL RULES (READ-ONLY)" -ForegroundColor Cyan
        Write-Host ('Total rules returned by ActiveStore: ' + $allRules.Count) -ForegroundColor Green
        Write-Host 'Includes local rules and applicable Group Policy / service-hardening rules.' -ForegroundColor Yellow
        Write-Host 'Filter details are read live from their associated filter objects; no rules are changed.' -ForegroundColor Gray

        for ($i = 0; $i -lt $allRules.Count; $i++) {
            $rule = $allRules[$i]
            $appText = 'Any'
            $serviceText = 'Any'
            $protocolText = 'Any'
            $localPortText = 'Any'
            $remotePortText = 'Any'
            $localAddressText = 'Any'
            $remoteAddressText = 'Any'
            $interfaceText = 'Any'

            try {
                $app = Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
                if ($app) {
                    if (-not [string]::IsNullOrWhiteSpace([string]$app.Program)) { $appText = [string]$app.Program }
                    elseif (-not [string]::IsNullOrWhiteSpace([string]$app.Package)) { $appText = 'Package: ' + [string]$app.Package }
                }
            } catch { $appText = '[filter unavailable]' }
            try {
                $service = Get-NetFirewallServiceFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
                if ($service) { $serviceText = ConvertTo-FirewallRuleDisplayValue $service.Service }
            } catch { $serviceText = '[filter unavailable]' }
            try {
                $port = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
                if ($port) {
                    $protocolText = ConvertTo-FirewallRuleDisplayValue $port.Protocol
                    $localPortText = ConvertTo-FirewallRuleDisplayValue $port.LocalPort
                    $remotePortText = ConvertTo-FirewallRuleDisplayValue $port.RemotePort
                }
            } catch { $protocolText = '[filter unavailable]' }
            try {
                $address = Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
                if ($address) {
                    $localAddressText = ConvertTo-FirewallRuleDisplayValue $address.LocalAddress
                    $remoteAddressText = ConvertTo-FirewallRuleDisplayValue $address.RemoteAddress
                }
            } catch { $localAddressText = '[filter unavailable]'; $remoteAddressText = '[filter unavailable]' }
            try {
                $interface = Get-NetFirewallInterfaceFilter -AssociatedNetFirewallRule $rule -ErrorAction Stop | Select-Object -First 1
                if ($interface) { $interfaceText = ConvertTo-FirewallRuleDisplayValue $interface.InterfaceAlias }
            } catch { $interfaceText = '[filter unavailable]' }

            $enabledColor = if ([string]$rule.Enabled -eq 'True') { 'Green' } else { 'DarkGray' }
            Write-Host ("`n[{0}/{1}] {2}" -f ($i + 1),$allRules.Count,[string]$rule.DisplayName) -ForegroundColor $enabledColor
            Write-Host ('  Name: ' + [string]$rule.Name + ' | Enabled: ' + [string]$rule.Enabled + ' | Direction: ' + [string]$rule.Direction + ' | Action: ' + [string]$rule.Action)
            Write-Host ('  Profile: ' + [string]$rule.Profile + ' | Group: ' + [string]$rule.Group)
            Write-Host ('  Policy source: ' + [string]$rule.PolicyStoreSourceType + ' | ' + [string]$rule.PolicyStoreSource)
            Write-Host ('  Application: ' + $appText + ' | Service: ' + $serviceText)
            Write-Host ('  Protocol: ' + $protocolText + ' | Local port: ' + $localPortText + ' | Remote port: ' + $remotePortText)
            Write-Host ('  Local address: ' + $localAddressText + ' | Remote address: ' + $remoteAddressText + ' | Interface: ' + $interfaceText)
        }
        Write-Host "`n[READ-ONLY COMPLETE] Displayed all rules returned by ActiveStore. No firewall rules were created, changed, enabled, disabled, or deleted." -ForegroundColor Green
    }
    catch {
        Write-Host ('[ALL-RULE REVIEW ERROR] ' + $_.Exception.Message) -ForegroundColor Red
        Write-Log ('All-firewall-rule review failed: ' + $_.Exception.Message) 'ERROR'
    }
}

function Invoke-BlockedEvent {
    param($EventRecord)
    $fields = Get-EventFieldMap -EventRecord $EventRecord
    $rawAppPath = [string]$fields['Application']
    $processId = [string]$fields['ProcessID']
    $directionCode = [string]$fields['Direction']
    $protocolNumber = [string]$fields['Protocol']
    $sourceAddress = [string]$fields['SourceAddress']
    $sourcePort = [string]$fields['SourcePort']
    $destAddress = [string]$fields['DestAddress']
    $destPort = [string]$fields['DestPort']
    $filterId = [string]$fields['FilterRTID']
    $layer = [string]$fields['LayerName']

    $direction = switch ($directionCode) {
        '%%14592' { 'Inbound' }
        '%%14593' { 'Outbound' }
        '%%14594' { 'Loopback' }
        default { 'Unknown' }
    }
    $protocol = Convert-ProtocolNumber -Number $protocolNumber
    $protocolLabel = if ($protocol -eq 'TCP' -or $protocol -eq 'UDP') { $protocol } elseif ($protocol) { 'IP protocol ' + $protocolNumber } else { 'Unknown protocol' }

    if ($direction -eq 'Inbound') {
        $remoteAddress = $sourceAddress; $remotePort = $sourcePort
        $localAddress = $destAddress; $localPort = $destPort
    }
    elseif ($direction -eq 'Outbound') {
        $remoteAddress = $destAddress; $remotePort = $destPort
        $localAddress = $sourceAddress; $localPort = $sourcePort
    }
    else {
        $remoteAddress = '-'; $remotePort = '-'
        $localAddress = '-'; $localPort = '-'
    }

    $appPath = Convert-DeviceApplicationPath -RawPath $rawAppPath
    $appName = if ($appPath) { Split-Path -Leaf $appPath } elseif ($rawAppPath) { $rawAppPath } else { 'Unknown application' }
    $remoteIpObject = $null
    $remoteIpValid = ($direction -in @('Inbound','Outbound')) -and [System.Net.IPAddress]::TryParse($remoteAddress,[ref]$remoteIpObject)
    $isPortProtocol = $protocol -in @('TCP','UDP')
    $portValid = $false
    $portNumber = 0
    if ($isPortProtocol -and [int]::TryParse($remotePort,[ref]$portNumber) -and $portNumber -ge 0 -and $portNumber -le 65535) { $portValid = $true }

    # Security event 5157 can emit a new RecordId for every packet in one flow.
    # Use the connection tuple (not RecordId or PID) so [I] ignores repeat records
    # for this exact application/flow until the monitor stops. Nothing is persisted.
    $sessionIgnoreKey = $null
    if ($appPath -and $direction -in @('Inbound','Outbound') -and $remoteIpValid) {
        $sessionIdentity = @(
            [Environment]::ExpandEnvironmentVariables($appPath).ToLowerInvariant()
            $direction.ToUpperInvariant()
            ([string]$protocol).ToUpperInvariant()
            ([string]$localAddress).ToLowerInvariant()
            ([string]$localPort)
            ([string]$remoteIpObject.IPAddressToString).ToLowerInvariant()
            ([string]$remotePort)
        ) -join '|'
        $sessionIgnoreKey = Get-Sha256Hex -Text $sessionIdentity
        if ($script:SessionIgnoredConnectionKeys.ContainsKey($sessionIgnoreKey)) { return }
    }

    $timestamp = $EventRecord.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "`n[$timestamp] [BLOCKED CONNECTION] [Record $($EventRecord.RecordId)]" -ForegroundColor Red
    Write-Host ('  Direction:       ' + $direction) -ForegroundColor Yellow
    Write-Host ('  Application:     ' + $appName) -ForegroundColor Yellow
    Write-Host ('  Process ID:      ' + $processId) -ForegroundColor Gray
    Write-Host ('  Local endpoint:  ' + $localAddress + ':' + $localPort) -ForegroundColor Gray
    Write-Host ('  Remote endpoint: ' + $remoteAddress + ':' + $remotePort) -ForegroundColor Cyan
    Write-Host ('  Protocol:        ' + $protocolLabel) -ForegroundColor Magenta
    Write-Host ('  Filter / layer:  ' + $filterId + ' / ' + $layer) -ForegroundColor DarkGray
    if ($rawAppPath -and -not $appPath) {
        Write-Host ('  Raw app path:    ' + $rawAppPath) -ForegroundColor DarkGray
        Write-Host '  Rule actions unavailable: application path could not be safely mapped to a local file.' -ForegroundColor Yellow
    }

    if (-not $appPath -or $direction -notin @('Inbound','Outbound')) {
        Write-Host '  This event is informational only; no application rule can safely be created.' -ForegroundColor Gray
        return
    }

    # First consult saved PersistentStore rules. This works across monitor restarts,
    # unlike a session-only decision cache, and prevents a second prompt for a flow
    # already covered by a managed application-wide or target-specific rule.
    try {
        if (-not $script:ManagedRuleCacheReady) { Update-ManagedRuleCache | Out-Null }
    }
    catch {
        Write-Host ('  [RULE INDEX UNAVAILABLE] ' + $_.Exception.Message) -ForegroundColor Red
        Write-Host '  No new rule will be created until saved managed rules can be checked safely.' -ForegroundColor Yellow
        return
    }
    $eventProtocolForRule = if ($protocol) { [string]$protocol } else { 'Any' }
    $eventPortForRule = if ($isPortProtocol -and $portValid) { [string]$portNumber } else { 'Any' }
    $eventAddressForDecision = if ($remoteIpValid) { [string]$remoteIpObject.IPAddressToString } else { 'Any' }
    $savedMatch = Find-ManagedRuleForEvent -ProgramPath $appPath -Direction $direction `
        -RemoteAddress $(if ($remoteIpValid) { $remoteIpObject.IPAddressToString } else { 'Any' }) `
        -RemotePort $eventPortForRule -Protocol $eventProtocolForRule
    if ($savedMatch) {
        Write-Host ('  [AUTO-SKIP - SAVED RULE ALREADY COVERS THIS CONNECTION] ' + $savedMatch.Rule.DisplayName) -ForegroundColor Green
        Write-Host ('  Saved decision: ' + $savedMatch.Action + ' | Group: ' + $savedMatch.Rule.Group) -ForegroundColor Gray
        return
    }

    $trustInfo = $null
    try { $trustInfo = Get-ApplicationTrustInfo -ProgramPath $appPath }
    catch { Write-Host ('  [FINGERPRINT UNAVAILABLE] ' + $_.Exception.Message) -ForegroundColor Yellow }
    if ($trustInfo -and $remoteIpValid) {
        try {
            $remembered = Find-RememberedIgnoreDecision -ProgramPath $appPath -ExecutableSHA256 $trustInfo.SHA256 -Direction $direction -RemoteAddress $eventAddressForDecision -RemotePort $eventPortForRule -Protocol $eventProtocolForRule
            if ($remembered) {
                Write-Host ('  [AUTO-SKIP - REMEMBERED IGNORE] Same executable fingerprint and connection; expires ' + $remembered.ExpiresUtc) -ForegroundColor DarkYellow
                return
            }
        }
        catch { Write-Host ('  [DECISION MEMORY UNAVAILABLE] ' + $_.Exception.Message + ' — continuing interactively.') -ForegroundColor Yellow; Write-Log ('Remembered-decision lookup failed: ' + $_.Exception.Message) 'WARNING' }
    }

    Write-Host '  Actions for this direction:' -ForegroundColor Cyan
    Write-Host '     [1] Allow application for this direction' -ForegroundColor Yellow
    if ($remoteIpValid) { Write-Host '     [2] Allow this remote IP (and port when applicable)' -ForegroundColor Yellow }
    else { Write-Host '     [2] Allow remote target (unavailable: invalid IP)' -ForegroundColor DarkGray }
    Write-Host '     [3] Block application for this direction' -ForegroundColor Red
    if ($remoteIpValid) { Write-Host '     [4] Block this remote IP (and port when applicable)' -ForegroundColor Red }
    else { Write-Host '     [4] Block remote target (unavailable: invalid IP)' -ForegroundColor DarkGray }
    Write-Host '     [T] Timed ALLOW application (expiry noted; rule is retained)' -ForegroundColor Green
    Write-Host '     [V] Timed BLOCK application (expiry noted; rule is retained)' -ForegroundColor Red
    Write-Host '     [I] Ignore this exact connection for this monitor session (NO firewall rule; suppress repeats)' -ForegroundColor Gray
    if ($remoteIpValid) { Write-Host '     [J] Remember IGNORE for this exact connection (default 7 days)' -ForegroundColor DarkYellow }
    $choice = (Read-Host '  Your choice').Trim().ToUpperInvariant()
    if ($choice -eq 'I') {
        if ($sessionIgnoreKey) {
            $script:SessionIgnoredConnectionKeys[$sessionIgnoreKey] = $true
            # Keep memory bounded during long monitoring sessions.
            if ($script:SessionIgnoredConnectionKeys.Count -gt 5000) {
                $script:SessionIgnoredConnectionKeys.Clear()
                $script:SessionIgnoredConnectionKeys[$sessionIgnoreKey] = $true
            }
            Write-Host '  [IGNORED FOR THIS MONITOR SESSION] Repeated records for this exact flow will be silently skipped. No firewall rule was created.' -ForegroundColor Green
        }
        else {
            Write-Host '  [IGNORED ONCE] This event could not be safely keyed as an exact IP connection. No firewall rule was created.' -ForegroundColor Gray
        }
        return
    }
    if ([string]::IsNullOrWhiteSpace($choice)) { return }
    if ($choice -eq 'J') {
        if (-not $remoteIpValid) { Write-Host '  Cannot remember a connection without a valid remote IP.' -ForegroundColor Yellow; return }
        if (-not $trustInfo) { Write-Host '  Cannot remember this decision without a valid executable SHA-256.' -ForegroundColor Yellow; return }
        $daysText=(Read-Host '  Remember duration in days (1-365, Enter=7)').Trim()
        $days=7
        if ($daysText -and (-not [int]::TryParse($daysText,[ref]$days) -or $days -lt 1 -or $days -gt 365)) { Write-Host '  Invalid duration; nothing saved.' -ForegroundColor Yellow; return }
        try {
            Add-RememberedIgnoreDecision -ProgramPath $appPath -ExecutableSHA256 $trustInfo.SHA256 -Direction $direction -RemoteAddress $eventAddressForDecision -RemotePort $eventPortForRule -Protocol $eventProtocolForRule -Days $days
            Write-Host ('  [DECISION REMEMBERED] Exact connection will be ignored for {0} day(s), unless the executable changes.' -f $days) -ForegroundColor Green
        } catch { Write-Host ('  [DECISION NOT SAVED] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('Could not save remembered decision: ' + $_.Exception.Message) 'ERROR' }
        return
    }

    $action = $null
    $scope = 'Application'
    $temporary = $false
    switch ($choice) {
        '1' { $action = 'Allow' }
        '2' { if ($remoteIpValid) { $action = 'Allow'; $scope = 'Target' } }
        '3' { $action = 'Block' }
        '4' { if ($remoteIpValid) { $action = 'Block'; $scope = 'Target' } }
        'T' { $action = 'Allow'; $temporary = $true }
        'V' { $action = 'Block'; $temporary = $true }
        default { Write-Host '  Invalid choice; no change made.' -ForegroundColor Gray; return }
    }
    if (-not $action) { Write-Host '  Target is not a valid IP address; no rule was created.' -ForegroundColor Yellow; return }

    if ($action -eq 'Allow') {
        if (-not $trustInfo) { Write-Host '  [TRUST CHECK FAILED] Executable fingerprint could not be verified; allow rule cancelled.' -ForegroundColor Red; return }
        Write-Host ('  Executable SHA-256: '+$trustInfo.SHA256) -ForegroundColor Gray
        Write-Host ('  Authenticode:      '+$trustInfo.SignatureStatus) -ForegroundColor $(if($trustInfo.SignatureStatus -eq 'Valid'){'Green'}else{'Yellow'})
        if ($trustInfo.Publisher) { Write-Host ('  Publisher:         '+$trustInfo.Publisher) -ForegroundColor Gray }
        Write-Host ('  Classification:    '+$trustInfo.Classification) -ForegroundColor DarkYellow
        if ($trustInfo.SignatureStatus -ne 'Valid') {
            Write-Host '  WARNING: Executable does not have a currently valid Authenticode signature.' -ForegroundColor Yellow
            $trustConfirm=Read-Host '  Type TRUST to approve this unsigned/untrusted executable'
            if ($trustConfirm -cne 'TRUST') { Write-Host '  Allow rule cancelled.' -ForegroundColor Gray; return }
        }
    }
    $expiresUtc=$null
    if ($temporary) {
        $minutesText=(Read-Host '  Expiry reminder in minutes (1-10080, Enter=60; this script will not remove the rule)').Trim()
        $minutes=60
        if ($minutesText -and (-not [int]::TryParse($minutesText,[ref]$minutes) -or $minutes -lt 1 -or $minutes -gt 10080)) {
            Write-Host '  Invalid duration. No rule was created.' -ForegroundColor Yellow; return
        }
        $expiresUtc=[DateTimeOffset]::UtcNow.AddMinutes($minutes)
    }

    # Build the identity from the actual firewall rule parameters. In particular,
    # an application-wide rule must NOT include the event's remote IP or port.
    $parameters = @{
        Group = $ManagedRuleGroup
        Direction = $direction
        Program = $appPath
        Action = $action
        Profile = 'Any'
        Enabled = 'True'
    }
    $parameters.Description = New-ManagedRuleDescription -TrustInfo $trustInfo -ExpiresUtc $expiresUtc -Action $action
    if ($scope -eq 'Target') {
        $parameters.RemoteAddress = [string]$remoteIpObject.IPAddressToString
        $parameters.Protocol = [string]$protocol
        if ($isPortProtocol -and $portValid) { $parameters.RemotePort = [string]$portNumber }
    }
    $identityProtocol = if ($parameters.ContainsKey('Protocol')) { Normalize-FilterValue $parameters.Protocol 'Protocol' } else { 'Any' }
    $identityAddress = if ($parameters.ContainsKey('RemoteAddress')) { Normalize-FilterValue $parameters.RemoteAddress 'Address' } else { 'Any' }
    $identityPort = if ($parameters.ContainsKey('RemotePort')) { Normalize-FilterValue $parameters.RemotePort 'Port' } else { 'Any' }
    $ruleText = @(
        [Environment]::ExpandEnvironmentVariables($appPath).ToLowerInvariant()
        $direction.ToUpperInvariant()
        $action.ToUpperInvariant()
        'ANY'
        $identityAddress
        $identityProtocol
        $identityPort
    ) -join '|'
    $shortHash = Get-RuleHash -Text $ruleText
    $stableName = 'ZT_R_' + $shortHash
    $prefix = if ($action -eq 'Allow') { 'ZeroTrust Allow' } else { 'ZeroTrust Block' }
    $scopeLabel = if ($scope -eq 'Application') { 'App' } else { 'Target' }
    $safeAppName = $appName
    if ($safeAppName.Length -gt 72) { $safeAppName = $safeAppName.Substring(0,72) }
    $displayName = '{0} {1} - {2} - {3}' -f $prefix,$scopeLabel,$safeAppName,$shortHash
    $parameters.Name = $stableName
    $parameters.DisplayName = $displayName

    $result = New-ZeroTrustFirewallRule -RuleParameters $parameters
    if ($result.Status -in @('Created','AlreadyExists')) {
        Write-Log ('[' + $result.Status + '] ' + $action + ' ' + $scope + ' ' + $direction + ' ' + $appPath + ' to ' + $remoteAddress + ':' + $remotePort)
        if ($result.Status -eq 'Created') {
            Write-Host ('  [FIREWALL RULE CREATED AND VERIFIED] ' + $result.Rule.DisplayName) -ForegroundColor Green
        }
        else {
            Write-Host ('  [FIREWALL RULE ALREADY EXISTS - NO DUPLICATE] ' + $result.Rule.DisplayName) -ForegroundColor DarkYellow
        }
    }
    else {
        Write-Host ('  [FIREWALL RULE CREATION FAILED] ' + $result.Message) -ForegroundColor Red
        Write-Log ('[RULE FAILED] ' + $result.Message + ' | ' + $appPath) 'ERROR'
    }
}

function Get-FilteringPlatformAuditState {
    # Event 5157 is the monitor's input for interactive rule decisions.
    try {
        $output = (& auditpol.exe /get /subcategory:$AuditSubcategoryGuid 2>&1 | Out-String)
        $exitCode = $LASTEXITCODE
        if ($exitCode -ne 0) {
            return [pscustomobject]@{ State='Unknown'; Output=$output.Trim(); ExitCode=$exitCode }
        }
        $targetLine = @($output -split "`r?`n" | Where-Object { $_ -match '(?i)Filtering Platform Connection' } | Select-Object -First 1)
        if ($targetLine.Count -eq 0) {
            return [pscustomobject]@{ State='Unknown'; Output=$output.Trim(); ExitCode=0 }
        }
        $setting = [string]$targetLine[0]
        if ($setting -match '(?i)\b(Success\s+and\s+Failure|Failure)\b') {
            return [pscustomobject]@{ State='Enabled'; Output=$setting.Trim(); ExitCode=0 }
        }
        if ($setting -match '(?i)\b(No Auditing|Success)\b') {
            return [pscustomobject]@{ State='Disabled'; Output=$setting.Trim(); ExitCode=0 }
        }
        return [pscustomobject]@{ State='Unknown'; Output=$setting.Trim(); ExitCode=0 }
    }
    catch {
        return [pscustomobject]@{ State='Unknown'; Output=$_.Exception.Message; ExitCode=-1 }
    }
}

function Read-FilteringPlatformAuditSnapshot {
    if (-not (Test-Path -LiteralPath $AuditStatePath -PathType Leaf)) { return $null }
    $envelope = Get-Content -LiteralPath $AuditStatePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace([string]$envelope.PayloadJson) -or [string]::IsNullOrWhiteSpace([string]$envelope.Sha256)) {
        throw 'Filtering Platform audit backup is incomplete; it has not been used.'
    }
    $actual = Get-Sha256Hex -Text ([string]$envelope.PayloadJson)
    if ($actual -ne [string]$envelope.Sha256) { throw 'Filtering Platform audit backup SHA-256 integrity check failed; file retained.' }
    $snapshot = [string]$envelope.PayloadJson | ConvertFrom-Json -ErrorAction Stop
    if ([int]$snapshot.SchemaVersion -ne 1 -or
        [string]$snapshot.ComputerName -ne [string]$env:COMPUTERNAME -or
        [string]$snapshot.SubcategoryGuid -ne [string]$AuditSubcategoryGuid -or
        $snapshot.FailureEnabled -isnot [bool]) {
        throw 'Filtering Platform audit backup schema, computer identity, or subcategory mismatch; file retained.'
    }
    return $snapshot
}

function Save-FilteringPlatformAuditSnapshot {
    param([Parameter(Mandatory=$true)][bool]$FailureEnabled)
    Ensure-StateDirectory
    if (Test-Path -LiteralPath $AuditStatePath -PathType Leaf) {
        # Preserve the first observed pre-change state until the Restore operation.
        $null = Read-FilteringPlatformAuditSnapshot
        return
    }
    $payload = [ordered]@{
        SchemaVersion = 1
        ComputerName = $env:COMPUTERNAME
        SubcategoryGuid = $AuditSubcategoryGuid
        FailureEnabled = [bool]$FailureEnabled
        CreatedUtc = [DateTime]::UtcNow.ToString('o')
    }
    $payloadJson = ConvertTo-Json -InputObject $payload -Depth 4 -Compress
    $envelope = [ordered]@{ PayloadJson=$payloadJson; Sha256=(Get-Sha256Hex -Text $payloadJson) }
    $json = ConvertTo-Json -InputObject $envelope -Depth 4
    $tempPath = $AuditStatePath + '.' + $PID + '.tmp'
    try {
        [IO.File]::WriteAllText($tempPath,$json,(New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tempPath -Destination $AuditStatePath -Force -ErrorAction Stop
    }
    finally {
        if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
    }
    Write-Log ('Saved original Filtering Platform Connection Failure auditing state: ' + [bool]$FailureEnabled)
}

function Ensure-FilteringPlatformFailureAuditing {
    $state = Get-FilteringPlatformAuditState
    if ($state.State -eq 'Enabled') {
        Write-Host '[AUDIT READY] Filtering Platform Connection Failure auditing is enabled.' -ForegroundColor Green
        return $true
    }
    if ($state.State -ne 'Disabled') {
        Write-Host ('[AUDIT STATE UNKNOWN] Cannot safely determine whether event 5157 auditing is enabled: ' + $state.Output) -ForegroundColor Red
        Write-Host 'No monitor was started because event-driven rule creation cannot be verified.' -ForegroundColor Yellow
        return $false
    }

    Write-Host '[RULE CREATION BLOCKER] Filtering Platform Connection Failure auditing is disabled.' -ForegroundColor Red
    Write-Host 'The monitor needs Security event 5157 to detect blocked connections and offer rule decisions.' -ForegroundColor Yellow
    $answer = Read-Host 'Enable Failure auditing now and restore its original setting later with main-menu option [2]? Type ENABLE'
    if ($answer -cne 'ENABLE') {
        Write-Host 'Audit policy was not changed. Monitor not started; no rule prompts can be generated.' -ForegroundColor Yellow
        return $false
    }

    # Save the prior setting before changing it; Restore [2] will revert only
    # this Failure-auditing flag and leave the Success-auditing flag untouched.
    Save-FilteringPlatformAuditSnapshot -FailureEnabled $false
    & auditpol.exe /set /subcategory:$AuditSubcategoryGuid /failure:enable
    $setCode = $LASTEXITCODE
    if ($setCode -ne 0) {
        throw ('Could not enable Filtering Platform Connection Failure auditing (auditpol exit code ' + $setCode + '). A Group Policy may control this setting.')
    }
    $verify = Get-FilteringPlatformAuditState
    if ($verify.State -ne 'Enabled') {
        throw ('Failure auditing did not verify as enabled. Current state: ' + $verify.State + ' | ' + $verify.Output)
    }
    Write-Log 'Enabled Filtering Platform Connection Failure auditing after explicit user approval.'
    Write-Host '[AUDIT ENABLED AND VERIFIED] New blocked connections can now generate event 5157.' -ForegroundColor Green
    return $true
}

function Restore-FilteringPlatformAuditSnapshot {
    param($Snapshot,[switch]$KeepBackup)
    if ($null -eq $Snapshot) { return }
    $desired = if ([bool]$Snapshot.FailureEnabled) { 'enable' } else { 'disable' }
    $failureArgument = '/failure:' + $desired
    & auditpol.exe /set /subcategory:$AuditSubcategoryGuid $failureArgument
    $setCode = $LASTEXITCODE
    if ($setCode -ne 0) {
        throw ('Could not restore original Filtering Platform Failure auditing setting (auditpol exit code ' + $setCode + '). The audit backup was retained.')
    }
    $verify = Get-FilteringPlatformAuditState
    $expectedState = if ([bool]$Snapshot.FailureEnabled) { 'Enabled' } else { 'Disabled' }
    if ($verify.State -ne $expectedState) {
        throw ('Filtering Platform audit restore verification failed. Expected ' + $expectedState + '; found ' + $verify.State + '. Backup retained.')
    }
    Write-Host ('[AUDIT RESTORED] Original Filtering Platform Connection Failure auditing: ' + $expectedState) -ForegroundColor Green
    Write-Log ('Restored original Filtering Platform Connection Failure auditing state: ' + $expectedState)
    if (-not $KeepBackup -and (Test-Path -LiteralPath $AuditStatePath -PathType Leaf)) {
        $archive = Join-Path $StateDirectory ('FilteringPlatformAuditState.restored-{0}.json' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
        Move-Item -LiteralPath $AuditStatePath -Destination $archive -ErrorAction Stop
        Write-Host ('Audit backup archived: ' + $archive) -ForegroundColor Gray
    }
}

function Get-SecurityLogCursor {
    $latest = Get-WinEvent -LogName Security -MaxEvents 1 -ErrorAction Stop
    if ($latest) { return [long]$latest.RecordId }
    return [long]0
}

function Start-Monitor {
    param([Parameter(Mandatory=$true)][long]$StartingRecordId)
    Write-Host "`n=====================================================================" -ForegroundColor Cyan
    Write-Host '             ZERO-TRUST FIREWALL CONNECTION MONITOR' -ForegroundColor Cyan
    Write-Host '              Phase 1-5 build 0.7.7 - WIRESHARK GUI / FULL FIREWALL BACKUP' -ForegroundColor Magenta
    Write-Host '=====================================================================' -ForegroundColor Cyan
    Write-Host 'Firewall policy: verified strict defaults; existing rules are read-only.' -ForegroundColor Yellow
    Write-Host 'Monitoring only NEW Security event 5157 records; older events are not replayed.' -ForegroundColor Gray
    Write-Host 'Automatic rule prompts require Filtering Platform Connection Failure auditing.' -ForegroundColor Yellow
    Write-Host 'Press Ctrl+C to stop monitoring. The enforced firewall policy remains active.' -ForegroundColor Gray
    Write-Host 'Existing firewall rules are never modified by this monitor.' -ForegroundColor Gray

    Write-Host "`nFiltering Platform Connection audit policy:" -ForegroundColor Cyan
    & auditpol.exe /get /subcategory:$AuditSubcategoryGuid
    if (-not (Ensure-FilteringPlatformFailureAuditing)) {
        Write-Host 'The strict firewall policy remains active. Use main-menu option [2] to restore your saved firewall settings.' -ForegroundColor Yellow
        return
    }

    $lastRecordId = $StartingRecordId
    $expiredAtStart = Get-ExpiredManagedRules
    $managedCount = Update-ManagedRuleCache
    $integrityWarnings = Test-ManagedRuleIntegrity
    Write-Host ('Loaded ' + $script:ManagedRuleCache.Count + ' saved managed firewall rule(s) for repeat-prompt suppression.') -ForegroundColor Gray
    if ($expiredAtStart -gt 0) { Write-Host ('Found '+$expiredAtStart+' expired temporary rule(s); all were retained unchanged.') -ForegroundColor Yellow }
    if ($integrityWarnings -gt 0) { Write-Host ('Found '+$integrityWarnings+' executable-integrity warning(s); all firewall rules were retained unchanged.') -ForegroundColor Red }
    Write-Host ('Listening from Security event record ' + $lastRecordId + '...') -ForegroundColor Green
    Write-Log ('Monitor started. Initial Security EventRecordID=' + $lastRecordId)

    while ($true) {
        try {
            $xpath = '*[System[(EventID=5157) and (EventRecordID > ' + $lastRecordId + ')]]'
            # -Oldest ensures a full batch is processed from the lowest RecordId
            # upward; default newest-first retrieval could skip intermediate events.
            $events = @(Get-WinEvent -LogName Security -FilterXPath $xpath -Oldest -MaxEvents 512 -ErrorAction Stop)
        }
        catch {
            Write-Warning ('Security event query failed: ' + $_.Exception.Message)
            Start-Sleep -Seconds 5
            continue
        }

        if ($events.Count -ge 512) {
            Write-Warning 'A full 512-event batch was returned; additional events may remain and will be processed in the next polling cycle.'
        }
        foreach ($eventRecord in $events) {
            if ([long]$eventRecord.RecordId -le $lastRecordId) { continue }
            $lastRecordId = [long]$eventRecord.RecordId
            try { Invoke-BlockedEvent -EventRecord $eventRecord }
            catch {
                Write-Host ('[EVENT PARSE/PROCESS ERROR] Record ' + $eventRecord.RecordId + ': ' + $_.Exception.Message) -ForegroundColor Red
                Write-Log ('Event processing error for record ' + $eventRecord.RecordId + ': ' + $_.Exception.Message) 'ERROR'
            }
        }
        Start-Sleep -Seconds 2
    }
}

function Write-CaptureMessage { param([string]$Message,[string]$Color='Gray'); Write-Host $Message -ForegroundColor $Color }
function Ensure-CaptureDirectory {
    if (-not (Test-Path -LiteralPath $CaptureDirectory)) { New-Item -ItemType Directory -Path $CaptureDirectory -Force -ErrorAction Stop | Out-Null }
    foreach ($protectedPath in @($StateDirectory,$CaptureDirectory)) {
        & icacls.exe $protectedPath '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' *> $null
        if ($LASTEXITCODE -ne 0) { throw ('Could not restrict capture directory permissions: ' + $protectedPath) }
    }
}
function Get-Sha256Text { param([string]$Text); $sha=[Security.Cryptography.SHA256]::Create(); try { ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-','') } finally { $sha.Dispose() } }
function Get-PktmonState {
    # pktmon status output differs across Windows builds. Some versions do not
    # print the words RUNNING/ACTIVE; they instead print the active capture
    # sections shown below. Parse those structured markers as well.
    $output = (& $Pktmon status 2>&1 | Out-String)
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw ('pktmon status failed (exit '+$code+'): '+$output.Trim()) }

    $logMatch = [regex]::Match($output,'(?im)^\s*Log file:\s*(.+?)\s*$')
    $reportedLog = if ($logMatch.Success) { $logMatch.Groups[1].Value.Trim().Trim('"') } else { $null }
    $text = $output.Trim()

    # Explicit stopped indicators take precedence over generic words such as
    # "capture" or "collected" which can also appear in help/status text.
    if ($output -match '(?im)^\s*(Status|State)\s*:\s*(Stopped|Not running)\s*$' -or
        $output -match '(?i)packet monitor is not running|no active capture|capture is stopped|not currently running') {
        return [pscustomobject]@{ State='Stopped'; Text=$text; LogFilePath=$reportedLog }
    }

    $hasActiveLogger = ($output -match '(?im)^\s*Collected Data\s*:' -and
                        $output -match '(?im)^\s*Logger Parameters\s*:' -and
                        $output -match '(?im)^\s*Log file\s*:\s*\S')
    if ($hasActiveLogger -or $output -match '(?i)\b(running|active)\b') {
        return [pscustomobject]@{ State='Running'; Text=$text; LogFilePath=$reportedLog }
    }

    if ($output -match '(?i)not\s+running|\bstopped\b|not active') {
        return [pscustomobject]@{ State='Stopped'; Text=$text; LogFilePath=$reportedLog }
    }
    return [pscustomobject]@{ State='Unknown'; Text=$text; LogFilePath=$reportedLog }
}
function Enter-PktmonMutex {
    $script:Mutex = New-Object System.Threading.Mutex($false,$MutexName)
    $script:MutexOwned = $false
    try { $script:MutexOwned = $script:Mutex.WaitOne([TimeSpan]::FromSeconds(8)) }
    catch [System.Threading.AbandonedMutexException] { $script:MutexOwned = $true }
    if (-not $script:MutexOwned) { throw 'Another ZeroTrust capture operation is in progress.' }
}
function Exit-PktmonMutex {
    if ($script:MutexOwned -and $script:Mutex) { try { $script:Mutex.ReleaseMutex() } catch { } }
    if ($script:Mutex) { $script:Mutex.Dispose() }
    $script:Mutex=$null; $script:MutexOwned=$false
}
function Save-OwnerMarker {
    param([hashtable]$Payload)
    $payloadJson=ConvertTo-Json -InputObject $Payload -Depth 5 -Compress
    $envelope=[ordered]@{PayloadJson=$payloadJson;Sha256=(Get-Sha256Text $payloadJson)}
    $json=ConvertTo-Json -InputObject $envelope -Depth 4
    $temp=$OwnerPath+'.'+$PID+'.tmp'
    try { [IO.File]::WriteAllText($temp,$json,(New-Object Text.UTF8Encoding($false))); Move-Item -LiteralPath $temp -Destination $OwnerPath -Force -ErrorAction Stop }
    finally { if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue} }
}
function Read-OwnerMarker {
    if (-not (Test-Path -LiteralPath $OwnerPath -PathType Leaf)) { throw 'No ZeroTrust ownership marker exists. Refusing to stop an unowned pktmon session.' }
    $envlp=Get-Content -LiteralPath $OwnerPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if (-not $envlp.PayloadJson -or -not $envlp.Sha256 -or (Get-Sha256Text ([string]$envlp.PayloadJson)) -ne [string]$envlp.Sha256) { throw 'Capture ownership marker failed integrity validation. Refusing to stop pktmon.' }
    $payload=[string]$envlp.PayloadJson | ConvertFrom-Json -ErrorAction Stop
    if ([string]$payload.ComputerName -ne $env:COMPUTERNAME -or [int]$payload.SchemaVersion -ne 1) { throw 'Capture marker belongs to another machine or schema. Refusing to stop pktmon.' }
    $full=[IO.Path]::GetFullPath([string]$payload.EtlPath)
    $base=[IO.Path]::GetFullPath($CaptureDirectory).TrimEnd('\')+'\'
    if (-not $full.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)) { throw 'Capture marker ETL path is outside the capture directory.' }
    return $payload
}
function Start-ZTCapture {
    Enter-PktmonMutex
    try {
        $status=Get-PktmonState
        if ($status.State -eq 'Running') { throw 'pktmon is already running. No ownership marker was created and the existing session was left untouched.' }
        if ($status.State -ne 'Stopped') { throw ('pktmon status is ambiguous; refusing to start: '+$status.Text) }
        if (Test-Path -LiteralPath $OwnerPath) {
            $stale=Join-Path $CaptureDirectory ('PktmonOwner.stale-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')
            Move-Item -LiteralPath $OwnerPath -Destination $stale -ErrorAction Stop
            Write-CaptureMessage ('Archived stale ownership marker: '+$stale) 'Yellow'
        }
        $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
        $etl=Join-Path $CaptureDirectory ('ZeroTrust-Capture-'+$stamp+'-'+([guid]::NewGuid().ToString('N').Substring(0,8))+'.etl')
        # Capture NIC packets only; 512-byte snap length and 128-MB circular cap limit exposure/storage.
        & $Pktmon start --capture --comp nics --pkt-size 512 --file-name $etl --file-size 128 --log-mode circular
        $startCode=$LASTEXITCODE
        if ($startCode -ne 0) { throw ('pktmon start failed with exit code '+$startCode+'.') }
        $after=Get-PktmonState
        if ($after.State -ne 'Running') {
            # This start command succeeded and the earlier state was stopped; cleanup is limited to our successful start attempt.
            try { & $Pktmon stop | Out-Null } catch { }
            throw ('pktmon did not report an active capture after start: '+$after.Text)
        }
        if ($after.LogFilePath) {
            $reported=[IO.Path]::GetFullPath([string]$after.LogFilePath)
            $requested=[IO.Path]::GetFullPath($etl)
            if (-not $reported.Equals($requested,[StringComparison]::OrdinalIgnoreCase)) {
                throw ('pktmon reports a different active ETL path than the one requested. Refusing to claim ownership. Status: '+$after.Text)
            }
        }
        $payload=@{SchemaVersion=1;ComputerName=$env:COMPUTERNAME;RunId=[guid]::NewGuid().ToString('D');StartedUtc=[DateTime]::UtcNow.ToString('o');OwnerPid=$PID;EtlPath=$etl;PktmonStatus=$after.Text}
        try { Save-OwnerMarker -Payload $payload }
        catch { try { & $Pktmon stop | Out-Null } catch { }; throw ('Capture started, but ownership marker could not be saved; stop was attempted. '+$_.Exception.Message) }
        Write-CaptureMessage '[CAPTURE STARTED] ZeroTrust owns this pktmon session.' 'Green'
        Write-CaptureMessage ('ETL: '+$etl) 'Gray'
        Write-CaptureMessage 'When finished, choose Stop + convert. Original ETL will be retained.' 'Cyan'
    }
    finally { Exit-PktmonMutex }
}
function Invoke-CaptureAnalysis {
    param([string]$PcapPath)

    # Wireshark.exe is the only supported analyzer/launcher in this build.
    # The command-line dependency and its automatic text audit are removed.
    if (-not (Test-Path -LiteralPath $PcapPath -PathType Leaf)) {
        Write-CaptureMessage ('Wireshark launch preparation skipped: PCAPNG file not found: ' + $PcapPath) 'Yellow'
        return
    }

    $wireshark = Find-Wireshark
    if ([string]::IsNullOrWhiteSpace([string]$wireshark)) {
        Write-CaptureMessage 'Wireshark.exe was not found. The PCAPNG is saved; use menu [5] after installing or locating Wireshark.' 'Yellow'
        return
    }

    try {
        $versionInfo = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($wireshark)
        $productName = [string]$versionInfo.ProductName
        $fileDescription = [string]$versionInfo.FileDescription
        $originalFilename = [string]$versionInfo.OriginalFilename
        $versionText = [string]$versionInfo.ProductVersion
        if ([string]::IsNullOrWhiteSpace($versionText)) { $versionText = [string]$versionInfo.FileVersion }

        $identityVerified = (
            $productName -match '(?i)Wireshark' -or
            $fileDescription -match '(?i)Wireshark' -or
            $originalFilename -match '(?i)^Wireshark\.exe$'
        )
        if (-not $identityVerified -or $versionText -notmatch '\d+\.\d+') {
            Write-CaptureMessage 'Wireshark.exe was found but its embedded version metadata could not be verified. Automatic analysis was skipped.' 'Yellow'
            return
        }

        Write-CaptureMessage ('Wireshark selected: ' + $wireshark) 'Gray'
        Write-CaptureMessage ('Verified version: ' + $versionText.Trim()) 'Gray'
        Write-CaptureMessage 'Automatic command-line analysis is disabled. Open this PCAPNG with menu [5] for interactive analysis in Wireshark.' 'Cyan'
    } catch {
        Write-CaptureMessage ('Wireshark metadata verification failed: ' + $_.Exception.Message + '. PCAPNG is preserved; use menu [5] to retry.') 'Yellow'
    }
}
function Stop-ZTCapture {
    Enter-PktmonMutex
    try {
        $owner=Read-OwnerMarker
        $status=Get-PktmonState
        if($status.State -eq 'Unknown'){throw ('pktmon status ambiguous; refusing to stop: '+$status.Text)}
        if($status.State -eq 'Running'){
            if ([string]::IsNullOrWhiteSpace([string]$status.LogFilePath)) {
                throw 'pktmon status does not expose its active log file path. Cannot safely prove that the running session is the owned capture; refusing to stop it. Ownership marker retained.'
            }
            $activePath=[IO.Path]::GetFullPath([string]$status.LogFilePath)
            $ownedPath=[IO.Path]::GetFullPath([string]$owner.EtlPath)
            if (-not $activePath.Equals($ownedPath,[StringComparison]::OrdinalIgnoreCase)) {
                throw ('The active pktmon ETL path does not match the ZeroTrust-owned ETL path. Refusing to stop another capture. Active: '+$activePath+' | Owned: '+$ownedPath)
            }
            & $Pktmon stop
            if($LASTEXITCODE -ne 0){throw ('pktmon stop failed with exit code '+$LASTEXITCODE+'. Ownership marker retained.')}
            $after=Get-PktmonState
            if($after.State -ne 'Stopped'){throw ('pktmon did not verify as stopped; ownership marker retained. '+$after.Text)}
        }
        else { Write-CaptureMessage 'pktmon is already stopped; no stop command was issued.' 'Yellow' }
        $etl=[string]$owner.EtlPath
        if(-not (Test-Path -LiteralPath $etl -PathType Leaf)){throw ('Owned ETL file is missing: '+$etl+'. Marker retained.')}
        $pcap=[IO.Path]::ChangeExtension($etl,'.pcapng')
        & $Pktmon etl2pcap $etl --out $pcap
        if($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $pcap -PathType Leaf)){throw 'ETL-to-PCAPNG conversion failed. Original ETL and ownership marker retained.'}
        $done=Join-Path $CaptureDirectory ('PktmonOwner.completed-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')
        Move-Item -LiteralPath $OwnerPath -Destination $done -ErrorAction Stop
        Write-CaptureMessage '[CAPTURE STOPPED AND CONVERTED]' 'Green'
        Write-CaptureMessage ('ETL (original): '+$etl) 'Gray'
        Write-CaptureMessage ('PCAPNG: '+$pcap) 'Gray'
        Invoke-CaptureAnalysis -PcapPath $pcap
    }
    finally { Exit-PktmonMutex }
}
function Show-CaptureStatus {
    try {
        $status=Get-PktmonState
        Write-CaptureMessage ('pktmon state: '+$status.State) $(if($status.State -eq 'Running'){'Yellow'}elseif($status.State -eq 'Stopped'){'Green'}else{'Red'})
        Write-CaptureMessage $status.Text 'Gray'
        if(Test-Path -LiteralPath $OwnerPath){
            try{$o=Read-OwnerMarker; Write-CaptureMessage ('ZeroTrust-owned session: '+$o.RunId+' | '+$o.EtlPath) 'Cyan'}
            catch{Write-CaptureMessage ('Ownership marker invalid: '+$_.Exception.Message) 'Red'}
        } else { Write-CaptureMessage 'No ZeroTrust ownership marker present.' 'Gray' }
    } catch { Write-CaptureMessage ('[STATUS ERROR] '+$_.Exception.Message) 'Red' }
}

function Find-Wireshark {
    # Locate the interactive Wireshark GUI. The portable location is checked first.
    $paths = New-Object System.Collections.Generic.List[string]
    [void]$paths.Add('C:\Software\WiresharkPortable64\App\Wireshark\Wireshark.exe')

    if (-not [string]::IsNullOrWhiteSpace([string]$env:Software)) {
        try {
            [void]$paths.Add((Join-Path -Path $env:Software -ChildPath 'WiresharkPortable64\App\Wireshark\Wireshark.exe'))
        } catch { }
    }

    $cmd = Get-Command -Name 'Wireshark.exe' -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) {
        $commandPath = [string]$cmd.Source
        if ([string]::IsNullOrWhiteSpace($commandPath)) { $commandPath = [string]$cmd.Path }
        if ([string]::IsNullOrWhiteSpace($commandPath)) { $commandPath = [string]$cmd.Definition }
        if (-not [string]::IsNullOrWhiteSpace($commandPath)) { [void]$paths.Add($commandPath) }
    }

    if ($env:ProgramFiles) {
        [void]$paths.Add((Join-Path -Path $env:ProgramFiles -ChildPath 'Wireshark\Wireshark.exe'))
    }
    if (${env:ProgramFiles(x86)}) {
        [void]$paths.Add((Join-Path -Path ${env:ProgramFiles(x86)} -ChildPath 'Wireshark\Wireshark.exe'))
    }

    foreach ($candidate in ($paths | Select-Object -Unique)) {
        if ([string]::IsNullOrWhiteSpace([string]$candidate)) { continue }
        try {
            $fullPath = [System.IO.Path]::GetFullPath([string]$candidate)
            if (Test-Path -LiteralPath $fullPath -PathType Leaf) {
                return $fullPath
            }
        } catch { }
    }
    return $null
}

function Start-WiresharkOnLatestCapture {
    # Open the newest completed capture in the interactive Wireshark GUI.
    $wireshark = Find-Wireshark
    if ([string]::IsNullOrWhiteSpace([string]$wireshark)) {
        throw 'Wireshark.exe was not found. Checked C:\Software\WiresharkPortable64\App\Wireshark, PATH, and standard installation folders.'
    }

    $captures = @(Get-ChildItem -LiteralPath $CaptureDirectory -Filter '*.pcapng' -File -ErrorAction Stop |
        Sort-Object -Property LastWriteTimeUtc -Descending)
    if ($captures.Count -eq 0) {
        throw ('No PCAPNG captures were found in: ' + $CaptureDirectory + '. Stop and convert a capture first.')
    }

    $pcap = [string]$captures[0].FullName
    if ((Get-Item -LiteralPath $pcap -ErrorAction Stop).Length -le 0) {
        throw ('The newest PCAPNG capture is empty: ' + $pcap)
    }

    # Verify the exact GUI executable using its embedded Windows version resource.
    # Do not run "Wireshark.exe -v" here: GUI builds can return exit code 0 while
    # writing no version text to the console (and may start/activate a GUI instance).
    try {
        $versionInfo = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($wireshark)
        $productName = [string]$versionInfo.ProductName
        $fileDescription = [string]$versionInfo.FileDescription
        $originalFilename = [string]$versionInfo.OriginalFilename
        $versionText = [string]$versionInfo.ProductVersion
        if ([string]::IsNullOrWhiteSpace($versionText)) {
            $versionText = [string]$versionInfo.FileVersion
        }

        $identityVerified = (
            $productName -match '(?i)Wireshark' -or
            $fileDescription -match '(?i)Wireshark' -or
            $originalFilename -match '(?i)^Wireshark\.exe$'
        )
        $versionVerified = $versionText -match '\d+\.\d+'
        if (-not $identityVerified -or -not $versionVerified) {
            throw ('Windows version metadata did not identify a versioned Wireshark executable. ProductName="' +
                $productName + '"; FileDescription="' + $fileDescription +
                '"; OriginalFilename="' + $originalFilename + '"; ProductVersion="' + $versionText + '".')
        }
    } catch {
        throw ('Wireshark.exe was found but its embedded Windows version information could not be verified. ' + $_.Exception.Message)
    }

    # Quote the capture path because the ProgramData path or capture filename may contain spaces.
    $argumentList = @('-r', ('"{0}"' -f $pcap))
    $process = Start-Process -FilePath $wireshark -ArgumentList $argumentList `
        -WorkingDirectory $CaptureDirectory -WindowStyle Normal -PassThru -ErrorAction Stop

    Write-CaptureMessage '[WIRESHARK LAUNCHED] Opening the selected capture in the Wireshark GUI.' 'Green'
    Write-CaptureMessage ('Wireshark: ' + $wireshark) 'Gray'
    Write-CaptureMessage ('Verified version: ' + $versionText.Trim()) 'Gray'
    Write-CaptureMessage ('PCAPNG: ' + $pcap) 'Gray'
    Write-CaptureMessage ('Process ID: ' + $process.Id) 'Gray'
}

function Wait-ForMenuReturn {
    param([string]$Context='This operation')
    Write-Host "`n$Context finished. The monitor is still running." -ForegroundColor DarkGray
    try { $null = Read-Host 'Press Enter to return to the main menu' }
    catch {
        Write-Host ('Console input was interrupted: ' + $_.Exception.Message) -ForegroundColor Yellow
        Start-Sleep -Milliseconds 700
    }
}

function Invoke-MenuActionSafely {
    param(
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [Parameter(Mandatory=$true)][string]$Context
    )
    try {
        & $Action
    }
    catch {
        $message = $_.Exception.Message
        Write-Host ('[' + $Context.ToUpperInvariant() + ' ERROR] ' + $message) -ForegroundColor Red
        try { Write-Log ($Context + ' failed: ' + $message) 'ERROR' } catch { }
    }
    finally {
        Wait-ForMenuReturn -Context $Context
    }
}

function Show-ZTCaptureMenu {
    if (-not (Test-Path -LiteralPath $Pktmon -PathType Leaf)) {
        throw 'pktmon.exe was not found. This Windows installation does not provide the in-box Packet Monitor utility.'
    }
    Ensure-CaptureDirectory
    while ($true) {
        Write-Host "`nZERO-TRUST PACKET CAPTURE (INTEGRATED)" -ForegroundColor Cyan
        Write-Host '[1] Start capture (NICs, 512-byte snap length, 128-MB circular file)' -ForegroundColor Green
        Write-Host '[2] Stop owned capture + convert to PCAPNG + verify Wireshark.exe' -ForegroundColor Yellow
        Write-Host '[3] Show pktmon / ownership status' -ForegroundColor Gray
        Write-Host '[5] Open the latest PCAPNG in Wireshark (GUI)' -ForegroundColor Cyan
        Write-Host '[Q] Return to main menu' -ForegroundColor Gray
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { try { Start-ZTCapture } catch { Write-CaptureMessage ('[START ERROR] ' + $_.Exception.Message) 'Red' } }
            '2' { try { Stop-ZTCapture } catch { Write-CaptureMessage ('[STOP ERROR] ' + $_.Exception.Message) 'Red' } }
            '3' { Show-CaptureStatus }
            '5' { try { Start-WiresharkOnLatestCapture } catch { Write-CaptureMessage ('[WIRESHARK LAUNCH ERROR] ' + $_.Exception.Message) 'Red' } }
            'Q' { return }
            default { Write-CaptureMessage 'No action selected.' 'Gray' }
        }
    }
}


try {
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this CMD file as Administrator.'
    }
    Import-Module NetSecurity -ErrorAction Stop
    Ensure-StateDirectory
    if (Test-Path -LiteralPath $StatePath -PathType Leaf) {
        try {
            $startupSnapshot = Read-FirewallSnapshot
            if ([int]$startupSnapshot.SchemaVersion -lt 2) {
                $null = Upgrade-LegacyFirewallSnapshotToFull
            }
        }
        catch {
            Write-Host ('[BACKUP UPGRADE NOTICE] ' + $_.Exception.Message) -ForegroundColor Yellow
            Write-Log ('Full-policy backup compatibility upgrade could not complete: ' + $_.Exception.Message) 'WARNING'
        }
    }

    while ($true) {
        try {
            Clear-Host
            Write-Host '=====================================================================' -ForegroundColor Cyan
        Write-Host '                    ZERO-TRUST FIREWALL MONITOR'                           -ForegroundColor Cyan
        Write-Host '                         Created by SheWolf'                               -ForegroundColor Yellow
        Write-Host '====================================================================' -ForegroundColor Cyan
        Write-Host '[1] Start monitor (apply and verify strict firewall policy)' -ForegroundColor Yellow
        Write-Host '[2] Firewall policy backup / restore (rulle.wfw)' -ForegroundColor Green
        Write-Host '[E] DNS / DoH encryption configuration audit' -ForegroundColor Cyan
        Write-Host '[R] Read-only review of ALL effective firewall rules' -ForegroundColor Gray
        Write-Host '[M] Read-only rule health audit (expiry / executable integrity)' -ForegroundColor Gray
        Write-Host '[I] Application intelligence (SHA-256 / publisher / classification / remembered decisions)' -ForegroundColor Cyan
        Write-Host '[C] Integrated pktmon capture (no separate capture window)' -ForegroundColor Cyan
        Write-Host '[Q] Quit' -ForegroundColor Gray

        $menuChoice = (Read-Host 'Select an option').Trim().ToUpperInvariant()
        if ($menuChoice -eq 'Q') { break }

        switch ($menuChoice) {
            '1' {
                try {
                    $startingRecordId = Get-SecurityLogCursor
                    if (Start-StrictFirewall) { Start-Monitor -StartingRecordId $startingRecordId }
                    else { Write-Host 'Monitor was not started because strict policy was not verified.' -ForegroundColor Yellow }
                }
                catch { Write-Host ('[MONITOR START ERROR] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('Monitor start failed: ' + $_.Exception.Message) 'ERROR' }
            }
            '2' { try { Show-FirewallPolicyBackupMenu } catch { Write-Host ('[POLICY BACKUP MENU ERROR] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('Policy backup menu failed: ' + $_.Exception.Message) 'ERROR' } }
            'E' { Invoke-MenuActionSafely -Context 'DNS / DoH audit' -Action { Show-DnsEncryptionAudit } }
            'R' { Invoke-MenuActionSafely -Context 'All firewall rules (read-only)' -Action { Show-AllFirewallRules } }
            'M' { Invoke-MenuActionSafely -Context 'Managed rule maintenance' -Action { Invoke-ZeroTrustMaintenance } }
            'I' {
                try { Show-ApplicationIntelligenceMenu }
                catch { Write-Host ('[APPLICATION INTELLIGENCE ERROR] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('Application intelligence failed: ' + $_.Exception.Message) 'ERROR'; Wait-ForMenuReturn -Context 'Application intelligence' }
            }
            'C' {
                try { Start-CaptureUtility }
                catch { Write-Host ('[CAPTURE MENU ERROR] ' + $_.Exception.Message) -ForegroundColor Red; Write-Log ('Capture menu failed: ' + $_.Exception.Message) 'ERROR'; Wait-ForMenuReturn -Context 'Capture menu' }
            }
            default { Write-Host 'No changes made. Select one of the listed options.' -ForegroundColor Gray }
        }
            if ($menuChoice -notin @('1','2','E','M','R','I','C')) {
                Write-Host "`nReturning to the main menu..." -ForegroundColor DarkGray
                Start-Sleep -Milliseconds 700
            }
        }
        catch {
            $menuError = $_.Exception.Message
            Write-Host ('[MAIN MENU OPERATION ERROR] ' + $menuError) -ForegroundColor Red
            try { Write-Log ('Main menu operation failed: ' + $menuError) 'ERROR' } catch { }
            Wait-ForMenuReturn -Context 'Main menu operation'
        }
    }
    Write-Host 'Zero-Trust Firewall Monitor closed.' -ForegroundColor Gray
}

catch {
    Write-Host ('[FATAL ERROR] ' + $_.Exception.Message) -ForegroundColor Red
    try { Write-Log ('Fatal error: ' + $_.Exception.Message) 'ERROR' } catch { }
    Write-Host 'The monitor stopped after a fatal error. The PowerShell window will remain open so the message can be read.' -ForegroundColor Yellow
    try { $null = Read-Host 'Press Enter to close this window' } catch { Start-Sleep -Seconds 5 }
}
